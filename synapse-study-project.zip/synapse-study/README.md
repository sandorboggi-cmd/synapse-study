# Synapse Study

A personal, local-first Android study app for advanced biology/chemistry
revision, Hungarian erettsegi preparation, and medical-university prep -
built around a source-grounded Study AI that only answers from your own
uploaded materials (SOURCE_ONLY mode).

This is a single-user personal project. No accounts, no cloud backend, no
ads, no analytics, no Play Store publishing pipeline.

## Status

See [docs/STATUS.md](docs/STATUS.md) for exactly what has been generated,
what is functional vs. stubbed, and what has (not) been verified.
**Nothing in this repository has been compiled or run yet** - see
[SETUP_REQUIRED.md](SETUP_REQUIRED.md) for what you need to do first.

## Tech stack

Kotlin, Jetpack Compose, Material 3 (+ Adaptive), Hilt, Room (+ FTS4),
Proto/Preferences DataStore, WorkManager, Android Keystore-backed encrypted
storage, Media3. No Firebase, no cloud infrastructure.

## Project structure

```
synapse-study/
  android/
    app/                    entry point, single Activity, Compose NavHost
    core/                   common, model, domain, database, datastore,
                            security, sync, designsystem, navigation,
                            notifications, testing, ui
    feature/                onboarding, dashboard, tasks, calendar,
                            studyhub, library, sourceviewer, studyai,
                            assets, focus, music, search, settings, wellness
  docs/
    STATUS.md               build/feature status, always up to date
  README.md
  SETUP_REQUIRED.md
  CHANGELOG.md
```

## Getting started

1. Open `synapse-study/android/` in Android Studio (latest stable).
2. Let Gradle sync. **Expect and report the first sync/build errors** -
   this codebase has been generated and statically reviewed but never
   compiled in a real toolchain.
3. Run on a phone/tablet running Android 10+ (minSdk 26).
4. Optionally add your Gemini API key in Settings once the app runs -
   without one, Study AI uses a fully functional local fake provider so
   you can test the whole SOURCE_ONLY flow offline.

## Core AI behavior (non-negotiable)

Study AI defaults to **SOURCE_ONLY**: it only answers using text you've
selected from your own sources, cites every factual claim with a source
anchor, and says "I cannot find support for that in the selected
materials" when it can't. This is enforced in code
(`feature/studyai/provider/ResponseValidator.kt`), not just in a prompt -
citations referencing evidence that wasn't actually retrieved are dropped
and the answer is downgraded to PARTIAL/UNSUPPORTED automatically.
