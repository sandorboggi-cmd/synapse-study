# Changelog

All notable changes to this project are documented here. This project is
personal/unreleased, so versions track internal generation sessions rather
than public releases.

## [0.1.0] - 2026-08-03 - Phase 0 + Phase 1 source generation

### Added
- Full Gradle Kotlin DSL project skeleton, version catalog, 25-module structure
- core:common, core:model (22 domain entities), core:database (Room + FTS4 + DAOs + 1 instrumented test)
- core:datastore, core:security (Keystore-backed Gemini key storage), core:sync (Local Only working, Google Drive honestly stubbed)
- core:designsystem (Material3 + AMOLED), core:navigation (5-tab bottom nav), core:ui, core:notifications, core:testing
- feature:dashboard, feature:tasks (full CRUD), feature:calendar, feature:studyhub, feature:library, feature:sourceviewer
- feature:studyai: StudyAiProvider abstraction, LocalFakeStudyAiProvider (functional), GeminiStudyAiProvider (key handling functional, network call stubbed), SOURCE_ONLY prompt contract, ResponseValidator (citation enforcement, 4 unit tests), EvidenceRetriever (FTS-scoped), full chat pipeline
- feature:assets, feature:focus (timer engine + 3 unit tests), feature:music, feature:search, feature:settings (Gemini key UI), feature:wellness (isolated module), feature:onboarding
- docs/STATUS.md, README.md, SETUP_REQUIRED.md

### Known limitations
- Nothing compiled or run - no JDK/Android SDK/emulator available during generation
- Real PDF/OCR extraction, real Gemini network call, semantic retrieval, and Google Drive OAuth are intentionally stubbed with honest error states rather than faked
- Task Detail tabs, tablet two/three-pane layouts, WorkManager notification workers, and Compose UI tests are not yet implemented
