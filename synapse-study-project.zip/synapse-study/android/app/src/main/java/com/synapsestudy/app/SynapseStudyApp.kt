package com.synapsestudy.app

import android.app.Application
import com.synapsestudy.core.notifications.NotificationChannels
import dagger.hilt.android.HiltAndroidApp

/**
 * Application entry point. Creates notification channels on cold start
 * so Settings > notification toggles have real OS channels to point at
 * from the very first launch.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
@HiltAndroidApp
class SynapseStudyApp : Application() {
    override fun onCreate() {
        super.onCreate()
        NotificationChannels.ensureChannelsCreated(this)
    }
}
