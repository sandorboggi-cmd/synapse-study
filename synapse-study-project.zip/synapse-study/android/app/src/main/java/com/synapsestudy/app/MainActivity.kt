package com.synapsestudy.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.Modifier
import androidx.navigation.compose.rememberNavController
import com.synapsestudy.core.designsystem.theme.SynapseStudyTheme
import com.synapsestudy.core.navigation.SynapseNavHost
import dagger.hilt.android.AndroidEntryPoint

/**
 * Single Activity hosting the full Compose navigation graph. Adaptive
 * width detection (phone vs tablet) happens inside SynapseNavHost via
 * WindowSizeClass, not here.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
@AndroidEntryPoint
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            SynapseStudyTheme {
                Surface(modifier = Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    val navController = rememberNavController()
                    SynapseNavHost(navController = navController)
                }
            }
        }
    }
}
