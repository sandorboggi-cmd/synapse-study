pluginManagement {
    repositories { google(); mavenCentral(); gradlePluginPortal() }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories { google(); mavenCentral() }
}
rootProject.name = "synapse-study"
include(":app")
include(":core:common", ":core:model", ":core:domain", ":core:database", ":core:datastore",
    ":core:security", ":core:sync", ":core:designsystem", ":core:navigation",
    ":core:notifications", ":core:testing", ":core:ui")
include(":feature:onboarding", ":feature:dashboard", ":feature:tasks", ":feature:calendar",
    ":feature:studyhub", ":feature:library", ":feature:sourceviewer", ":feature:studyai",
    ":feature:assets", ":feature:focus", ":feature:music", ":feature:search",
    ":feature:settings", ":feature:wellness")
