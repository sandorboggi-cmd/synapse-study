package com.synapsestudy.feature.assets

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import com.synapsestudy.core.ui.components.SynapseEmptyState

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
@Composable
fun AssetsScreen(viewModel: AssetsViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()
    if (state.assets.isEmpty()) { SynapseEmptyState("No generated assets yet. Create summaries, flashcards, or quizzes from a source."); return }
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(state.assets, key = { it.id }) { asset ->
            ListItem(headlineContent = { Text(asset.title) }, supportingContent = { Text(asset.assetType) })
        }
    }
}
