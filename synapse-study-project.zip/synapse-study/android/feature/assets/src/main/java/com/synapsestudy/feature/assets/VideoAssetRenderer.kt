package com.synapsestudy.feature.assets

/**
 * Video summary generation is explicitly NOT implemented - no fake video
 * output is produced. Returns an honest not-supported result rather than
 * a placeholder video file, per project rule against faking generation
 * capabilities that don't exist yet.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
object VideoAssetRenderer {
    sealed interface VideoRenderResult {
        data object NotYetSupported : VideoRenderResult
    }

    fun render(sourceText: String): VideoRenderResult = VideoRenderResult.NotYetSupported
}
