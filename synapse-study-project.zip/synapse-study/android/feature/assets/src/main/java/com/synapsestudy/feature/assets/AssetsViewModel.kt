package com.synapsestudy.feature.assets

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.synapsestudy.core.database.dao.GeneratedAssetDao
import com.synapsestudy.core.database.entity.GeneratedAssetEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import javax.inject.Inject

data class AssetsUiState(val isLoading: Boolean = true, val assets: List<GeneratedAssetEntity> = emptyList())

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
@HiltViewModel
class AssetsViewModel @Inject constructor(private val generatedAssetDao: GeneratedAssetDao) : ViewModel() {
    private val _uiState = MutableStateFlow(AssetsUiState())
    val uiState: StateFlow<AssetsUiState> = _uiState.asStateFlow()

    init {
        generatedAssetDao.observeAll().onEach { assets ->
            _uiState.value = AssetsUiState(isLoading = false, assets = assets)
        }.launchIn(viewModelScope)
    }
}
