package com.synapsestudy.feature.assets.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.synapsestudy.core.navigation.SynapseDestination
import com.synapsestudy.feature.assets.AssetsScreen

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
fun NavGraphBuilder.assetsGraph(navController: NavHostController) {
    composable(SynapseDestination.Assets.route) { AssetsScreen() }
}
