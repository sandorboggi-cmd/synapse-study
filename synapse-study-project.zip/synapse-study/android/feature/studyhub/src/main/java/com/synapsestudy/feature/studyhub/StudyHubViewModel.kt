package com.synapsestudy.feature.studyhub

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.synapsestudy.core.common.Ids
import com.synapsestudy.core.common.TimeProvider
import com.synapsestudy.core.database.dao.StudyHubDao
import com.synapsestudy.core.database.entity.StudyHubEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import javax.inject.Inject

data class StudyHubListUiState(val isLoading: Boolean = true, val hubs: List<StudyHubEntity> = emptyList())

@HiltViewModel
class StudyHubViewModel @Inject constructor(
    private val studyHubDao: StudyHubDao,
    private val timeProvider: TimeProvider
) : ViewModel() {
    private val _uiState = MutableStateFlow(StudyHubListUiState())
    val uiState: StateFlow<StudyHubListUiState> = _uiState.asStateFlow()

    init {
        studyHubDao.observeAll().onEach { hubs -> _uiState.value = StudyHubListUiState(isLoading = false, hubs = hubs) }.launchIn(viewModelScope)
    }

    fun createHub(title: String, colorHex: String, iconKey: String) {
        viewModelScope.launch {
            val now = timeProvider.nowEpochMillis()
            studyHubDao.upsert(
                StudyHubEntity(
                    id = Ids.newId(), title = title, subjectId = null, examId = null,
                    colorHex = colorHex, iconKey = iconKey, readinessPercent = 0,
                    createdAt = now, updatedAt = now, schemaVersion = 1, isArchived = false
                )
            )
        }
    }

    fun archiveHub(hubId: String) { viewModelScope.launch { studyHubDao.archive(hubId, timeProvider.nowEpochMillis()) } }
}
