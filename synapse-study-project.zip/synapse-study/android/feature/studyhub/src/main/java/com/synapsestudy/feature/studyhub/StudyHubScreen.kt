package com.synapsestudy.feature.studyhub

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Card
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.synapsestudy.core.database.entity.StudyHubEntity
import com.synapsestudy.core.ui.components.SynapseEmptyState

@Composable
fun StudyHubScreen(onHubClick: (StudyHubEntity) -> Unit, viewModel: StudyHubViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()

    if (state.hubs.isEmpty()) { SynapseEmptyState("No Study Hubs yet. Create one for an exam or topic."); return }

    LazyVerticalGrid(columns = GridCells.Adaptive(minSize = 200.dp), modifier = Modifier.fillMaxSize().padding(8.dp)) {
        items(state.hubs, key = { it.id }) { hub ->
            Card(modifier = Modifier.padding(4.dp)) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(hub.title, style = MaterialTheme.typography.titleMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    LinearProgressIndicator(progress = { hub.readinessPercent / 100f })
                    Text("${'$'}{hub.readinessPercent}% ready")
                }
            }
        }
    }
}
