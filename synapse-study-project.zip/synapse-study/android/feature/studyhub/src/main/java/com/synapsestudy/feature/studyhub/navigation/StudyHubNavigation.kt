package com.synapsestudy.feature.studyhub.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.synapsestudy.core.navigation.SynapseDestination
import com.synapsestudy.feature.studyhub.StudyHubScreen

fun NavGraphBuilder.studyHubGraph(navController: NavHostController) {
    composable(SynapseDestination.StudyHub.route) {
        StudyHubScreen(onHubClick = { hub -> navController.navigate(SynapseDestination.StudyHubDetail.createRoute(hub.id)) })
    }
}
