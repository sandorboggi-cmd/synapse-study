package com.synapsestudy.feature.library

import com.synapsestudy.core.model.SourceProcessingState

interface SourceImportPipeline {
    suspend fun importFromUri(uriString: String, displayName: String): PipelineResult
    suspend fun importFromPastedText(text: String, title: String): PipelineResult
}

data class PipelineResult(val sourceId: String, val finalState: SourceProcessingState, val errorMessage: String? = null)

/**
 * Local-only pipeline. Real PDF text extraction/OCR not yet wired in this
 * session - honestly returns PARTIAL rather than pretending success.
 * STATUS: Generated, statically reviewed, not compiled.
 */
class LocalSourceImportPipeline : SourceImportPipeline {
    override suspend fun importFromUri(uriString: String, displayName: String): PipelineResult =
        PipelineResult("pending-real-implementation", SourceProcessingState.PARTIAL, "Text extraction not yet wired to a real PDF/OCR library.")

    override suspend fun importFromPastedText(text: String, title: String): PipelineResult =
        PipelineResult("pending-real-implementation", SourceProcessingState.READY)
}
