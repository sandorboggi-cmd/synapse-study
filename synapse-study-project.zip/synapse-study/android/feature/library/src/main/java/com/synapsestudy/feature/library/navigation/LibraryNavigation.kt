package com.synapsestudy.feature.library.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.synapsestudy.core.navigation.SynapseDestination
import com.synapsestudy.feature.library.LibraryScreen

fun NavGraphBuilder.libraryGraph(navController: NavHostController) {
    composable(SynapseDestination.Library.route) {
        LibraryScreen(onSourceClick = { source -> navController.navigate(SynapseDestination.SourceViewer.createRoute(source.id)) })
    }
}
