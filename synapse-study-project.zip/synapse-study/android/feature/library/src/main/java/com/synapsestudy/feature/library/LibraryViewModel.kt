package com.synapsestudy.feature.library

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.synapsestudy.core.database.dao.SourceDao
import com.synapsestudy.core.database.entity.SourceEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import javax.inject.Inject

data class LibraryUiState(val isLoading: Boolean = true, val sources: List<SourceEntity> = emptyList())

@HiltViewModel
class LibraryViewModel @Inject constructor(private val sourceDao: SourceDao) : ViewModel() {
    private val _uiState = MutableStateFlow(LibraryUiState())
    val uiState: StateFlow<LibraryUiState> = _uiState.asStateFlow()
    init { sourceDao.observeAll().onEach { _uiState.value = LibraryUiState(isLoading = false, sources = it) }.launchIn(viewModelScope) }
}
