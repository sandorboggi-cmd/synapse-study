package com.synapsestudy.feature.library

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ListItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import com.synapsestudy.core.database.entity.SourceEntity
import com.synapsestudy.core.ui.components.SynapseEmptyState

@Composable
fun LibraryScreen(onSourceClick: (SourceEntity) -> Unit, viewModel: LibraryViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()
    if (state.sources.isEmpty()) { SynapseEmptyState("No sources yet. Import a PDF, image, or paste text."); return }
    LazyColumn(modifier = Modifier.fillMaxSize()) {
        items(state.sources, key = { it.id }) { source ->
            ListItem(headlineContent = { Text(source.displayName) }, supportingContent = { Text("${'$'}{source.sourceType} - ${'$'}{source.processingState}") })
        }
    }
}
