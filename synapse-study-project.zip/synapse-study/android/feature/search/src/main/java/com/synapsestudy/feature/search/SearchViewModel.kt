package com.synapsestudy.feature.search

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.synapsestudy.core.database.dao.TaskDao
import com.synapsestudy.core.database.dao.SourceDao
import com.synapsestudy.core.database.dao.StudyHubDao
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.launch
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

data class SearchResultItem(val id: String, val title: String, val type: String)

data class SearchUiState(val query: String = "", val results: List<SearchResultItem> = emptyList(), val isSearching: Boolean = false)

/**
 * Unified local search across tasks, Study Hubs, and sources. Uses Room's
 * observeAll() + in-memory filtering for Phase 1 (small personal dataset);
 * the FTS-backed search across source chunk text already exists via
 * SourceChunkDao.searchFts and is wired in once cross-module scoping for
 * "search everything at once" is finalized.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
@HiltViewModel
class SearchViewModel @Inject constructor(
    private val taskDao: TaskDao,
    private val sourceDao: SourceDao,
    private val studyHubDao: StudyHubDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(SearchUiState())
    val uiState: StateFlow<SearchUiState> = _uiState.asStateFlow()

    fun search(query: String) {
        _uiState.value = _uiState.value.copy(query = query, isSearching = true)
        if (query.isBlank()) {
            _uiState.value = _uiState.value.copy(results = emptyList(), isSearching = false)
            return
        }
        viewModelScope.launch {
            val tasks = taskDao.observeAll().first().filter { it.title.contains(query, ignoreCase = true) }
                .map { SearchResultItem(it.id, it.title, "Task") }
            val sources = sourceDao.observeAll().first().filter { it.displayName.contains(query, ignoreCase = true) }
                .map { SearchResultItem(it.id, it.displayName, "Source") }
            val hubs = studyHubDao.observeAll().first().filter { it.title.contains(query, ignoreCase = true) }
                .map { SearchResultItem(it.id, it.title, "Study Hub") }
            _uiState.value = _uiState.value.copy(results = tasks + sources + hubs, isSearching = false)
        }
    }
}
