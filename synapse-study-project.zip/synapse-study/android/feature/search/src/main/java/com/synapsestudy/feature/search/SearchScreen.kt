package com.synapsestudy.feature.search

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import com.synapsestudy.core.ui.components.SynapseEmptyState

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
@Composable
fun SearchScreen(viewModel: SearchViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        OutlinedTextField(
            value = state.query,
            onValueChange = { viewModel.search(it) },
            label = { Text("Search tasks, hubs, sources") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
        if (state.results.isEmpty() && state.query.isNotBlank()) {
            SynapseEmptyState("No results for \"${'$'}{state.query}\"")
        } else {
            LazyColumn {
                items(state.results, key = { it.id }) { result ->
                    ListItem(headlineContent = { androidx.compose.material3.Text(result.title) }, supportingContent = { androidx.compose.material3.Text(result.type) })
                }
            }
        }
    }
}
