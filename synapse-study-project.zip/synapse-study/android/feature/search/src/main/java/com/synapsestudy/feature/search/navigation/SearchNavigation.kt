package com.synapsestudy.feature.search.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.synapsestudy.core.navigation.SynapseDestination
import com.synapsestudy.feature.search.SearchScreen

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
fun NavGraphBuilder.searchGraph(navController: NavHostController) {
    composable(SynapseDestination.Search.route) { SearchScreen() }
}
