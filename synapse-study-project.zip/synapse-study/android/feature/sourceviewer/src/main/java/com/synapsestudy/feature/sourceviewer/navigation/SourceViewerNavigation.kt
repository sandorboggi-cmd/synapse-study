package com.synapsestudy.feature.sourceviewer.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.NavType
import androidx.navigation.compose.composable
import androidx.navigation.compose.navArgument
import com.synapsestudy.core.navigation.SynapseDestination
import com.synapsestudy.feature.sourceviewer.SourceViewerScreen

fun NavGraphBuilder.sourceViewerGraph(navController: NavHostController) {
    composable(
        route = SynapseDestination.SourceViewer.route,
        arguments = listOf(navArgument("sourceId") { type = NavType.StringType })
    ) { backStackEntry ->
        val sourceId = backStackEntry.arguments?.getString("sourceId") ?: return@composable
        SourceViewerScreen(sourceId = sourceId)
    }
}
