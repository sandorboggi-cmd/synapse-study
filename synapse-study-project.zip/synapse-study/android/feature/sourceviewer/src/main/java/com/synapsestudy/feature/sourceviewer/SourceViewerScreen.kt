package com.synapsestudy.feature.sourceviewer

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

@Composable
fun SourceViewerScreen(sourceId: String, viewModel: SourceViewerViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()
    LaunchedEffect(sourceId) { viewModel.load(sourceId) }
    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(state.displayName ?: "Loading...")
        Text("Status: ${'$'}{state.processingState ?: "unknown"}")
        Text(state.extractedTextPreview ?: "No extracted text preview available yet.")
    }
}
