package com.synapsestudy.feature.sourceviewer

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.synapsestudy.core.database.dao.SourceDao
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SourceViewerUiState(val displayName: String? = null, val processingState: String? = null, val extractedTextPreview: String? = null)

@HiltViewModel
class SourceViewerViewModel @Inject constructor(private val sourceDao: SourceDao) : ViewModel() {
    private val _uiState = MutableStateFlow(SourceViewerUiState())
    val uiState: StateFlow<SourceViewerUiState> = _uiState.asStateFlow()

    fun load(sourceId: String) {
        viewModelScope.launch {
            val source = sourceDao.getById(sourceId)
            _uiState.value = SourceViewerUiState(displayName = source?.displayName, processingState = source?.processingState)
        }
    }
}
