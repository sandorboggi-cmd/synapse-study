package com.synapsestudy.feature.focus

import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * STATUS: Generated, statically reviewed, not run (no JDK in this
 * environment). Runnable via ./gradlew :feature:focus:testDebugUnitTest.
 */
class FocusTimerEngineTest {

    @Test
    fun `starting timer sets work phase with full duration`() {
        val engine = FocusTimerEngine(workSeconds = 1500, breakSeconds = 300, cyclesBeforeLongBreak = 4)
        engine.start()
        assertEquals(FocusPhase.WORK, engine.state.value.phase)
        assertEquals(1500, engine.state.value.remainingSeconds)
    }

    @Test
    fun `tick decrements remaining seconds`() {
        val engine = FocusTimerEngine(workSeconds = 10, breakSeconds = 5, cyclesBeforeLongBreak = 4)
        engine.start()
        engine.tick()
        assertEquals(9, engine.state.value.remainingSeconds)
    }

    @Test
    fun `reaching zero transitions from work to break`() {
        val engine = FocusTimerEngine(workSeconds = 2, breakSeconds = 5, cyclesBeforeLongBreak = 4)
        engine.start()
        engine.tick()
        engine.tick()
        assertEquals(FocusPhase.BREAK, engine.state.value.phase)
        assertEquals(5, engine.state.value.remainingSeconds)
        assertEquals(1, engine.state.value.cyclesCompleted)
    }
}
