package com.synapsestudy.feature.focus

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.synapsestudy.core.common.Ids
import com.synapsestudy.core.common.TimeProvider
import com.synapsestudy.core.database.dao.FocusSessionDao
import com.synapsestudy.core.database.entity.FocusSessionEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
@HiltViewModel
class FocusViewModel @Inject constructor(
    private val focusSessionDao: FocusSessionDao,
    private val timeProvider: TimeProvider
) : ViewModel() {

    private val engine = FocusTimerEngine(workSeconds = 25 * 60, breakSeconds = 5 * 60, cyclesBeforeLongBreak = 4)
    val timerState: StateFlow<FocusTimerState> = engine.state.asStateFlow()

    private var currentSessionId: String? = null
    private var tickerJob: kotlinx.coroutines.Job? = null

    fun startSession(taskId: String? = null) {
        val now = timeProvider.nowEpochMillis()
        val sessionId = Ids.newId()
        currentSessionId = sessionId
        engine.start()

        tickerJob?.cancel()
        tickerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                engine.tick()
            }
        }

        viewModelScope.launch {
            focusSessionDao.upsert(
                FocusSessionEntity(
                    id = sessionId, presetId = null, taskId = taskId, subjectId = null, examId = null, studyHubId = null,
                    startedAtEpochMillis = now, endedAtEpochMillis = null, actualFocusMinutes = 0, wasCompleted = false,
                    createdAt = now, updatedAt = now, schemaVersion = 1, isArchived = false
                )
            )
        }
    }

    fun stopSession() {
        tickerJob?.cancel()
        engine.stop()
        val sessionId = currentSessionId ?: return
        viewModelScope.launch {
            val now = timeProvider.nowEpochMillis()
            focusSessionDao.upsert(
                FocusSessionEntity(
                    id = sessionId, presetId = null, taskId = null, subjectId = null, examId = null, studyHubId = null,
                    startedAtEpochMillis = now, endedAtEpochMillis = now, actualFocusMinutes = 0, wasCompleted = true,
                    createdAt = now, updatedAt = now, schemaVersion = 1, isArchived = false
                )
            )
        }
    }
}
