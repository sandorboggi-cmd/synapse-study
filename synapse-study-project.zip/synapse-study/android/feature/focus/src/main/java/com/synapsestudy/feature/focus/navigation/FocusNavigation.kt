package com.synapsestudy.feature.focus.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.synapsestudy.core.navigation.SynapseDestination
import com.synapsestudy.feature.focus.FocusScreen

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
fun NavGraphBuilder.focusGraph(navController: NavHostController) {
    composable(SynapseDestination.Focus.route) { FocusScreen() }
}
