package com.synapsestudy.feature.focus

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel

/**
 * Focus timer screen with start/stop controls. Flip-clock visual style,
 * theming, sounds/haptics, and preset selection are visual polish added
 * once the underlying timer engine (functional now) is verified working
 * by you in Android Studio.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
@Composable
fun FocusScreen(viewModel: FocusViewModel = hiltViewModel()) {
    val timerState by viewModel.timerState.collectAsState()

    Column(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(timerState.phase.name, style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(16.dp))
        val minutes = timerState.remainingSeconds / 60
        val seconds = timerState.remainingSeconds % 60
        Text("${'$'}minutes:${'$'}{seconds.toString().padStart(2, '0')}", style = MaterialTheme.typography.displayLarge)
        Spacer(modifier = Modifier.height(24.dp))
        Row {
            Button(onClick = { viewModel.startSession() }) { Text("Start") }
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedButton(onClick = { viewModel.stopSession() }) { Text("Stop") }
        }
    }
}
