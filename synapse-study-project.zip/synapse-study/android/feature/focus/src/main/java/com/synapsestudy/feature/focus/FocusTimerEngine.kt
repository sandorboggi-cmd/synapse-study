package com.synapsestudy.feature.focus

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class FocusPhase { WORK, BREAK, IDLE }

data class FocusTimerState(
    val phase: FocusPhase = FocusPhase.IDLE,
    val remainingSeconds: Int = 0,
    val totalSeconds: Int = 0,
    val cyclesCompleted: Int = 0
)

/**
 * Pure countdown state machine (no Android framework dependency), so it is
 * trivially unit-testable. The actual foreground-service/notification tick
 * driver lives in FocusForegroundService and just calls tick() every second.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
class FocusTimerEngine(
    private val workSeconds: Int,
    private val breakSeconds: Int,
    private val cyclesBeforeLongBreak: Int
) {
    private val _state = MutableStateFlow(FocusTimerState())
    val state: StateFlow<FocusTimerState> = _state.asStateFlow()

    fun start() {
        _state.value = FocusTimerState(phase = FocusPhase.WORK, remainingSeconds = workSeconds, totalSeconds = workSeconds)
    }

    fun tick() {
        val current = _state.value
        if (current.phase == FocusPhase.IDLE) return
        if (current.remainingSeconds > 1) {
            _state.value = current.copy(remainingSeconds = current.remainingSeconds - 1)
        } else {
            transitionPhase(current)
        }
    }

    private fun transitionPhase(current: FocusTimerState) {
        _state.value = if (current.phase == FocusPhase.WORK) {
            current.copy(phase = FocusPhase.BREAK, remainingSeconds = breakSeconds, totalSeconds = breakSeconds, cyclesCompleted = current.cyclesCompleted + 1)
        } else {
            current.copy(phase = FocusPhase.WORK, remainingSeconds = workSeconds, totalSeconds = workSeconds)
        }
    }

    fun stop() { _state.value = FocusTimerState() }
}
