package com.synapsestudy.feature.studyai.provider

import com.synapsestudy.core.model.SupportStatus
import org.junit.Assert.assertEquals
import org.junit.Test

/**
 * Pure JVM unit tests, no Android dependency - runnable via
 * ./gradlew :feature:studyai:testDebugUnitTest.
 *
 * STATUS: Generated, statically reviewed, not run (no JVM available in
 * this generation environment either, but these need no Android SDK so
 * they should run cleanly under a real Gradle/JVM toolchain).
 */
class ResponseValidatorTest {

    private val evidence = listOf(
        EvidencePacket("ev1", "chunk1", "anchor1", "Bio Notes.pdf", 3, "Mitochondria produce ATP via oxidative phosphorylation."),
        EvidencePacket("ev2", "chunk2", "anchor2", "Bio Notes.pdf", 5, "The Krebs cycle occurs in the mitochondrial matrix.")
    )

    @Test
    fun `all citations valid keeps GROUNDED status`() {
        val response = StudyAiResponse(
            "Mitochondria produce ATP.", SupportStatus.GROUNDED,
            listOf(StudyAiCitation("ev1", "Mitochondria produce ATP via oxidative phosphorylation."))
        )
        val result = ResponseValidator.validate(response, evidence)
        assertEquals(SupportStatus.GROUNDED, result.supportStatus)
        assertEquals(1, result.citations.size)
    }

    @Test
    fun `invented citation is dropped and status downgraded to UNSUPPORTED`() {
        val response = StudyAiResponse(
            "Photosynthesis occurs in chloroplasts.", SupportStatus.GROUNDED,
            listOf(StudyAiCitation("ev999-invented", "This citation does not exist in evidence."))
        )
        val result = ResponseValidator.validate(response, evidence)
        assertEquals(SupportStatus.UNSUPPORTED, result.supportStatus)
        assertEquals(0, result.citations.size)
    }

    @Test
    fun `mix of valid and invented citations downgrades to PARTIAL`() {
        val response = StudyAiResponse(
            "Mitochondria produce ATP and photosynthesis happens there too.", SupportStatus.GROUNDED,
            listOf(
                StudyAiCitation("ev1", "Mitochondria produce ATP via oxidative phosphorylation."),
                StudyAiCitation("ev999-invented", "fabricated excerpt")
            )
        )
        val result = ResponseValidator.validate(response, evidence)
        assertEquals(SupportStatus.PARTIAL, result.supportStatus)
        assertEquals(1, result.citations.size)
        assertEquals("ev1", result.citations.first().evidenceId)
    }

    @Test
    fun `no citations at all keeps declared status if already non-GROUNDED`() {
        val response = StudyAiResponse("I cannot find support for that in the selected materials.", SupportStatus.UNSUPPORTED, emptyList())
        val result = ResponseValidator.validate(response, evidence)
        assertEquals(SupportStatus.UNSUPPORTED, result.supportStatus)
        assertEquals(0, result.citations.size)
    }
}
