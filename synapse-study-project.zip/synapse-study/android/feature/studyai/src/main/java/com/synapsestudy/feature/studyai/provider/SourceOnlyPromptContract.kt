package com.synapsestudy.feature.studyai.provider

object SourceOnlyPromptContract {

    const val SYSTEM_INSTRUCTION = """
You are Synapse Study AI in SOURCE_ONLY mode.
Use exclusively the evidence packets provided.
Do not use prior knowledge or outside information.
For each factual claim, cite the evidence packet IDs supporting it.
If evidence is insufficient, answer that the selected material does not support the requested claim.
Do not invent sources, citations, excerpts, pages, examples, definitions, or conclusions.
"""

    const val RESPONSE_JSON_SCHEMA_DESCRIPTION = """
{
  "answerText": string,
  "supportStatus": "GROUNDED" | "PARTIAL" | "UNSUPPORTED",
  "citations": [ { "evidenceId": string, "quotedExcerpt": string } ]
}
"""

    fun buildEvidenceBlock(evidence: List<EvidencePacket>): String =
        evidence.joinToString(separator = "\n\n") { packet ->
            "[Evidence ${'$'}{packet.evidenceId}] (Source: ${'$'}{packet.sourceDisplayName}" +
                (packet.pageNumber?.let { ", page ${'$'}it" } ?: "") + ")\n${'$'}{packet.text}"
        }
}
