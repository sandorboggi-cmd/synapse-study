package com.synapsestudy.feature.studyai.retrieval

import com.synapsestudy.core.database.dao.SourceAnchorDao
import com.synapsestudy.core.database.dao.SourceChunkDao
import com.synapsestudy.feature.studyai.provider.EvidencePacket
import javax.inject.Inject

class EvidenceRetriever @Inject constructor(
    private val sourceChunkDao: SourceChunkDao,
    private val sourceAnchorDao: SourceAnchorDao
) {
    suspend fun retrieveLexical(query: String, scopedSourceVersionIds: List<String>, maxResults: Int = 8): List<EvidencePacket> {
        if (scopedSourceVersionIds.isEmpty()) return emptyList()
        val ftsQuery = query.split(" ").filter { it.length > 2 }.joinToString(separator = " OR ").ifBlank { return emptyList() }
        val chunks = sourceChunkDao.searchFts(ftsQuery, scopedSourceVersionIds, maxResults)
        return chunks.mapNotNull { chunk ->
            val anchor = sourceAnchorDao.getById(chunk.anchorId) ?: return@mapNotNull null
            EvidencePacket(chunk.id, chunk.id, anchor.id, chunk.sourceVersionId, anchor.pageNumber, chunk.text)
        }
    }

    suspend fun retrieveSemantic(query: String, scopedSourceVersionIds: List<String>, maxResults: Int = 8): List<EvidencePacket> {
        throw NotImplementedError("Semantic retrieval is a future-ready interface, not implemented yet.")
    }
}
