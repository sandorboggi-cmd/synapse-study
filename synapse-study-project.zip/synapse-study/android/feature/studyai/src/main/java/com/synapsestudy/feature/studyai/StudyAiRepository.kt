package com.synapsestudy.feature.studyai

import com.synapsestudy.core.common.Ids
import com.synapsestudy.core.common.SynapseResult
import com.synapsestudy.core.common.TimeProvider
import com.synapsestudy.core.database.dao.ChatDao
import com.synapsestudy.core.database.dao.ChatMessageDao
import com.synapsestudy.core.database.dao.CitationAnchorDao
import com.synapsestudy.core.database.entity.ChatMessageEntity
import com.synapsestudy.core.database.entity.CitationAnchorEntity
import com.synapsestudy.feature.studyai.provider.StudyAiProvider
import com.synapsestudy.feature.studyai.provider.StudyAiRequest
import com.synapsestudy.feature.studyai.retrieval.EvidenceRetriever
import javax.inject.Inject

class StudyAiRepository @Inject constructor(
    private val provider: StudyAiProvider,
    private val evidenceRetriever: EvidenceRetriever,
    private val chatDao: ChatDao,
    private val chatMessageDao: ChatMessageDao,
    private val citationAnchorDao: CitationAnchorDao,
    private val timeProvider: TimeProvider
) {
    suspend fun askQuestion(chatId: String, question: String, scopedSourceVersionIds: List<String>): SynapseResult<String> {
        val now = timeProvider.nowEpochMillis()
        chatMessageDao.upsert(ChatMessageEntity(Ids.newId(), chatId, "USER", question, null, now, now, 1, false))

        val evidence = evidenceRetriever.retrieveLexical(question, scopedSourceVersionIds)
        val request = StudyAiRequest(question = question, evidence = evidence)

        return when (val result = provider.ask(request)) {
            is SynapseResult.Success -> {
                val response = result.data
                val assistantMessageId = Ids.newId()
                val ts = timeProvider.nowEpochMillis()
                chatMessageDao.upsert(ChatMessageEntity(assistantMessageId, chatId, "ASSISTANT", response.answerText, response.supportStatus.name, ts, ts, 1, false))
                response.citations.forEach { citation ->
                    val matchingEvidence = evidence.firstOrNull { it.evidenceId == citation.evidenceId }
                    if (matchingEvidence != null) {
                        val cts = timeProvider.nowEpochMillis()
                        citationAnchorDao.upsert(
                            CitationAnchorEntity(Ids.newId(), assistantMessageId, matchingEvidence.sourceAnchorId, matchingEvidence.sourceChunkId, citation.quotedExcerpt, cts, cts, 1, false)
                        )
                    }
                }
                SynapseResult.Success(assistantMessageId)
            }
            is SynapseResult.Error -> SynapseResult.Error(result.message, result.cause)
            is SynapseResult.Loading -> SynapseResult.Loading
        }
    }
}
