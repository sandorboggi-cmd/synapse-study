package com.synapsestudy.feature.studyai.provider

import com.synapsestudy.core.model.SupportStatus

object ResponseValidator {
    fun validate(response: StudyAiResponse, sentEvidence: List<EvidencePacket>): StudyAiResponse {
        val validIds = sentEvidence.map { it.evidenceId }.toSet()
        val validCitations = response.citations.filter { it.evidenceId in validIds }
        val adjustedStatus = when {
            validCitations.isEmpty() && response.supportStatus == SupportStatus.GROUNDED -> SupportStatus.UNSUPPORTED
            validCitations.size < response.citations.size -> SupportStatus.PARTIAL
            else -> response.supportStatus
        }
        return response.copy(citations = validCitations, supportStatus = adjustedStatus)
    }
}
