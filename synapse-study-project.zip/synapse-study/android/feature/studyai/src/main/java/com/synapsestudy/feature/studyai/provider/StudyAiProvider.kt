package com.synapsestudy.feature.studyai.provider

import com.synapsestudy.core.common.SynapseResult
import com.synapsestudy.core.model.SupportStatus

interface StudyAiProvider {
    val providerName: String
    suspend fun ask(request: StudyAiRequest): SynapseResult<StudyAiResponse>
    suspend fun testConnection(): SynapseResult<Unit>
}

data class EvidencePacket(
    val evidenceId: String, val sourceChunkId: String, val sourceAnchorId: String,
    val sourceDisplayName: String, val pageNumber: Int?, val text: String
)

data class StudyAiRequest(
    val question: String, val evidence: List<EvidencePacket>,
    val mode: com.synapsestudy.core.model.AiMode = com.synapsestudy.core.model.AiMode.SOURCE_ONLY
)

data class StudyAiCitation(val evidenceId: String, val quotedExcerpt: String)

data class StudyAiResponse(val answerText: String, val supportStatus: SupportStatus, val citations: List<StudyAiCitation>)
