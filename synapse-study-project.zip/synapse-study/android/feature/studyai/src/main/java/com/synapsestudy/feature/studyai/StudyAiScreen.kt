package com.synapsestudy.feature.studyai

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

/**
 * SOURCE_ONLY chat screen. Every assistant message shows its support
 * status (GROUNDED/PARTIAL/UNSUPPORTED) so the user always sees whether
 * an answer was actually backed by cited evidence.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
@Composable
fun StudyAiScreen(chatId: String, viewModel: StudyAiViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()
    var input by remember { mutableStateOf("") }

    LaunchedEffect(chatId) { viewModel.openChat(chatId) }

    Column(modifier = Modifier.fillMaxSize()) {
        LazyColumn(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
            items(state.messages, key = { it.id }) { message ->
                ListItem(
                    headlineContent = { Text(message.content) },
                    supportingContent = { Text("${'$'}{message.role}${'$'}{message.supportStatus?.let { " - ${'$'}it" } ?: ""}") }
                )
            }
        }
        state.errorMessage?.let { Text(it, color = MaterialTheme.colorScheme.error, modifier = Modifier.padding(8.dp)) }
        Row(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
            OutlinedTextField(value = input, onValueChange = { input = it }, modifier = Modifier.weight(1f), label = { Text("Ask about your sources") })
            Button(onClick = { if (input.isNotBlank()) { viewModel.sendQuestion(input); input = "" } }, enabled = !state.isSending) { Text("Send") }
        }
    }
}
