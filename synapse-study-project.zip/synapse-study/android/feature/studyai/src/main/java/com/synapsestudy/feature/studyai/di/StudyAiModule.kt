package com.synapsestudy.feature.studyai.di

import com.synapsestudy.core.security.EncryptedKeyStore
import com.synapsestudy.feature.studyai.provider.GeminiStudyAiProvider
import com.synapsestudy.feature.studyai.provider.LocalFakeStudyAiProvider
import com.synapsestudy.feature.studyai.provider.StudyAiProvider
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

/**
 * Auto-selects Gemini provider if a key is present, otherwise falls back
 * to the fully functional local fake provider so SOURCE_ONLY chat works
 * offline out of the box.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
@Module
@InstallIn(SingletonComponent::class)
object StudyAiModule {
    @Provides
    fun provideStudyAiProvider(
        encryptedKeyStore: EncryptedKeyStore,
        geminiProvider: GeminiStudyAiProvider,
        fakeProvider: LocalFakeStudyAiProvider
    ): StudyAiProvider = if (encryptedKeyStore.hasGeminiApiKey()) geminiProvider else fakeProvider
}
