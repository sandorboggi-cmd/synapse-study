package com.synapsestudy.feature.studyai.provider

import com.synapsestudy.core.common.SynapseResult
import com.synapsestudy.core.model.SupportStatus
import kotlinx.coroutines.delay
import javax.inject.Inject

class LocalFakeStudyAiProvider @Inject constructor() : StudyAiProvider {
    override val providerName: String = "Local Fake Provider (offline, deterministic)"

    override suspend fun ask(request: StudyAiRequest): SynapseResult<StudyAiResponse> {
        delay(300)
        if (request.evidence.isEmpty()) {
            return SynapseResult.Success(
                StudyAiResponse("I cannot find support for that in the selected materials.", SupportStatus.UNSUPPORTED, emptyList())
            )
        }
        val bestMatch = request.evidence.firstOrNull { chunk ->
            request.question.split(" ").any { word -> word.length > 3 && chunk.text.contains(word, ignoreCase = true) }
        } ?: request.evidence.first()
        val excerpt = bestMatch.text.take(200)
        val response = StudyAiResponse(
            "Based on ${'$'}{bestMatch.sourceDisplayName}: ${'$'}excerpt",
            SupportStatus.GROUNDED,
            listOf(StudyAiCitation(bestMatch.evidenceId, excerpt))
        )
        return SynapseResult.Success(ResponseValidator.validate(response, request.evidence))
    }

    override suspend fun testConnection(): SynapseResult<Unit> = SynapseResult.Success(Unit)
}
