package com.synapsestudy.feature.studyai

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.synapsestudy.core.common.SynapseResult
import com.synapsestudy.core.database.dao.ChatMessageDao
import com.synapsestudy.core.database.entity.ChatMessageEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import javax.inject.Inject

data class StudyAiUiState(
    val chatId: String? = null,
    val messages: List<ChatMessageEntity> = emptyList(),
    val selectedSourceVersionIds: List<String> = emptyList(),
    val isSending: Boolean = false,
    val errorMessage: String? = null
)

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
@HiltViewModel
class StudyAiViewModel @Inject constructor(
    private val repository: StudyAiRepository,
    private val chatMessageDao: ChatMessageDao
) : ViewModel() {

    private val _uiState = MutableStateFlow(StudyAiUiState())
    val uiState: StateFlow<StudyAiUiState> = _uiState.asStateFlow()

    fun openChat(chatId: String) {
        _uiState.value = _uiState.value.copy(chatId = chatId)
        chatMessageDao.observeByChat(chatId).onEach { messages ->
            _uiState.value = _uiState.value.copy(messages = messages)
        }.launchIn(viewModelScope)
    }

    fun setSelectedSources(sourceVersionIds: List<String>) {
        _uiState.value = _uiState.value.copy(selectedSourceVersionIds = sourceVersionIds)
    }

    fun sendQuestion(question: String) {
        val chatId = _uiState.value.chatId ?: return
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isSending = true, errorMessage = null)
            val result = repository.askQuestion(chatId, question, _uiState.value.selectedSourceVersionIds)
            _uiState.value = when (result) {
                is SynapseResult.Error -> _uiState.value.copy(isSending = false, errorMessage = result.message)
                else -> _uiState.value.copy(isSending = false)
            }
        }
    }
}
