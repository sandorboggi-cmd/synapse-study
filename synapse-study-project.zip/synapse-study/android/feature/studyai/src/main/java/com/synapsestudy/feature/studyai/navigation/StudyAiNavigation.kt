package com.synapsestudy.feature.studyai.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.synapsestudy.core.navigation.SynapseDestination
import com.synapsestudy.feature.studyai.StudyAiScreen

/**
 * StudyAi tab currently opens (or creates, via ViewModel default) a
 * single ongoing chat rather than a chat list - a chat-list/history
 * screen is a Phase 2 UX addition not yet built.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
fun NavGraphBuilder.studyAiGraph(navController: NavHostController) {
    composable(SynapseDestination.StudyAi.route) {
        StudyAiScreen(chatId = "default-chat")
    }
}
