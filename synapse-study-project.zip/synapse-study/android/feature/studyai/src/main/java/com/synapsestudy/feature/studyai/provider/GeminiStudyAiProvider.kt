package com.synapsestudy.feature.studyai.provider

import com.synapsestudy.core.common.SynapseResult
import com.synapsestudy.core.model.SupportStatus
import com.synapsestudy.core.security.EncryptedKeyStore
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import javax.inject.Inject

/**
 * Real network call intentionally throws NotImplementedError - no live
 * network/key available in this dev session. Documents exact endpoint.
 * STATUS: Generated, statically reviewed, not compiled, not tested against
 * a real Gemini endpoint.
 */
class GeminiStudyAiProvider @Inject constructor(
    private val encryptedKeyStore: EncryptedKeyStore
) : StudyAiProvider {
    override val providerName: String = "Gemini (personal API key)"
    private val json = Json { ignoreUnknownKeys = true }

    override suspend fun ask(request: StudyAiRequest): SynapseResult<StudyAiResponse> {
        val apiKey = encryptedKeyStore.getGeminiApiKey() ?: return SynapseResult.Error("No Gemini API key configured. Add one in Settings.")
        return try {
            val prompt = buildString {
                append(SourceOnlyPromptContract.SYSTEM_INSTRUCTION)
                append("\n\nEvidence:\n")
                append(SourceOnlyPromptContract.buildEvidenceBlock(request.evidence))
                append("\n\nQuestion: ${'$'}{request.question}")
                append("\n\nRespond as JSON matching this schema:\n")
                append(SourceOnlyPromptContract.RESPONSE_JSON_SCHEMA_DESCRIPTION)
            }
            val rawJson = callGeminiGenerateContent(apiKey, prompt)
            val parsed = json.decodeFromString<GeminiJsonResponse>(rawJson)
            val response = StudyAiResponse(
                answerText = parsed.answerText,
                supportStatus = runCatching { SupportStatus.valueOf(parsed.supportStatus) }.getOrDefault(SupportStatus.PARTIAL),
                citations = parsed.citations.map { StudyAiCitation(it.evidenceId, it.quotedExcerpt) }
            )
            SynapseResult.Success(ResponseValidator.validate(response, request.evidence))
        } catch (e: Exception) {
            SynapseResult.Error("Gemini request failed: ${'$'}{e.message}", e)
        }
    }

    override suspend fun testConnection(): SynapseResult<Unit> {
        val apiKey = encryptedKeyStore.getGeminiApiKey() ?: return SynapseResult.Error("No Gemini API key configured.")
        return try {
            callGeminiGenerateContent(apiKey, "Reply with OK.")
            SynapseResult.Success(Unit)
        } catch (e: Exception) {
            SynapseResult.Error("Connection test failed: ${'$'}{e.message}", e)
        }
    }

    private suspend fun callGeminiGenerateContent(apiKey: String, prompt: String): String {
        throw NotImplementedError(
            "Real HTTPS call to Gemini generateContent is not wired to a live network in this " +
                "development session. Implementation point: POST https://generativelanguage.googleapis.com/" +
                "v1beta/models/gemini-1.5-flash:generateContent?key=API_KEY with the prompt above as the " +
                "request body's text part."
        )
    }
}

@Serializable
private data class GeminiJsonResponse(val answerText: String, val supportStatus: String, val citations: List<GeminiCitationJson> = emptyList())

@Serializable
private data class GeminiCitationJson(val evidenceId: String, val quotedExcerpt: String)
