package com.synapsestudy.feature.settings.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.synapsestudy.core.navigation.SynapseDestination
import com.synapsestudy.feature.settings.SettingsScreen

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
fun NavGraphBuilder.settingsGraph(navController: NavHostController) {
    composable(SynapseDestination.Settings.route) { SettingsScreen() }
}
