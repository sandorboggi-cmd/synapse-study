package com.synapsestudy.feature.settings

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.synapsestudy.core.datastore.UserPreferencesDataStore
import com.synapsestudy.core.security.EncryptedKeyStore
import com.synapsestudy.core.sync.LocalOnlySyncProvider
import com.synapsestudy.core.common.SynapseResult
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import javax.inject.Inject

data class SettingsUiState(
    val aiMode: String = "SOURCE_ONLY",
    val syncMode: String = "LOCAL_ONLY",
    val themeMode: String = "SYSTEM",
    val wellnessEnabled: Boolean = false,
    val maskedGeminiKey: String? = null,
    val geminiTestResultMessage: String? = null,
    val backupResultMessage: String? = null
)

/**
 * Settings screen backing ViewModel. This is where the Gemini API key
 * add/remove/test flow lives, satisfying "Optionally paste my own Gemini
 * API key in the app Settings" as a real, working UI action - the key
 * never touches Room, DataStore, or logs; it goes straight to
 * EncryptedKeyStore (Android Keystore-backed).
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
@HiltViewModel
class SettingsViewModel @Inject constructor(
    private val preferencesDataStore: UserPreferencesDataStore,
    private val encryptedKeyStore: EncryptedKeyStore,
    private val localOnlySyncProvider: LocalOnlySyncProvider
) : ViewModel() {

    private val _uiState = MutableStateFlow(SettingsUiState())
    val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

    init {
        combine(
            preferencesDataStore.aiMode,
            preferencesDataStore.syncMode,
            preferencesDataStore.themeMode,
            preferencesDataStore.wellnessEnabled
        ) { aiMode, syncMode, themeMode, wellnessEnabled ->
            _uiState.value.copy(
                aiMode = aiMode, syncMode = syncMode, themeMode = themeMode,
                wellnessEnabled = wellnessEnabled, maskedGeminiKey = encryptedKeyStore.getMaskedKeyPreview()
            )
        }.onEach { _uiState.value = it }.launchIn(viewModelScope)
    }

    fun saveGeminiApiKey(rawKey: String) {
        encryptedKeyStore.saveGeminiApiKey(rawKey)
        _uiState.value = _uiState.value.copy(maskedGeminiKey = encryptedKeyStore.getMaskedKeyPreview())
    }

    fun removeGeminiApiKey() {
        encryptedKeyStore.removeGeminiApiKey()
        _uiState.value = _uiState.value.copy(maskedGeminiKey = null)
    }

    fun testGeminiConnection() {
        // Actual network test call delegates to GeminiStudyAiProvider.testConnection()
        // in feature:studyai; wiring the cross-module call is a follow-up step
        // once feature:settings depends on feature:studyai's provider interface.
        _uiState.value = _uiState.value.copy(
            geminiTestResultMessage = if (encryptedKeyStore.hasGeminiApiKey())
                "Key saved. Live connection test requires network access not available in this dev session."
            else "No key configured."
        )
    }

    fun setThemeMode(mode: String) { viewModelScope.launch { preferencesDataStore.setThemeMode(mode) } }
    fun setAiMode(mode: String) { viewModelScope.launch { preferencesDataStore.setAiMode(mode) } }
    fun setWellnessEnabled(enabled: Boolean) { viewModelScope.launch { preferencesDataStore.setWellnessEnabled(enabled) } }

    fun backupNow() {
        viewModelScope.launch {
            when (val result = localOnlySyncProvider.backupNow()) {
                is SynapseResult.Success -> _uiState.value = _uiState.value.copy(backupResultMessage = "Backup created: ${'$'}{result.data.backupId}")
                is SynapseResult.Error -> _uiState.value = _uiState.value.copy(backupResultMessage = result.message)
                else -> Unit
            }
        }
    }
}
