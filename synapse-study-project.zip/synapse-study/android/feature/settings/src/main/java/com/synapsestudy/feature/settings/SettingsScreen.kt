package com.synapsestudy.feature.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

/**
 * Settings screen: theme, AI mode (SOURCE_ONLY locked as default per spec),
 * wellness master toggle, Gemini key add/remove/test, and manual backup.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
@Composable
fun SettingsScreen(viewModel: SettingsViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()
    var apiKeyInput by remember { mutableStateOf("") }

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text("Appearance", style = MaterialTheme.typography.titleMedium)
        Row {
            listOf("LIGHT", "DARK", "SYSTEM", "AMOLED").forEach { mode ->
                FilterChip(
                    selected = state.themeMode == mode,
                    onClick = { viewModel.setThemeMode(mode) },
                    label = { Text(mode) },
                    modifier = Modifier.padding(4.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("Study AI mode", style = MaterialTheme.typography.titleMedium)
        Text("SOURCE_ONLY is the default and only fully supported mode; general knowledge modes are a future addition.")

        Spacer(modifier = Modifier.height(16.dp))
        Row(verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
            Text("Enable wellness module")
            Spacer(modifier = Modifier.weight(1f))
            Switch(checked = state.wellnessEnabled, onCheckedChange = { viewModel.setWellnessEnabled(it) })
        }

        Spacer(modifier = Modifier.height(16.dp))
        Text("Gemini API key", style = MaterialTheme.typography.titleMedium)
        Text(state.maskedGeminiKey ?: "No key configured. Using local fake provider.")
        OutlinedTextField(
            value = apiKeyInput,
            onValueChange = { apiKeyInput = it },
            label = { Text("Paste Gemini API key") },
            modifier = Modifier.fillMaxWidth()
        )
        Row {
            Button(onClick = { viewModel.saveGeminiApiKey(apiKeyInput); apiKeyInput = "" }) { Text("Save") }
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedButton(onClick = { viewModel.testGeminiConnection() }) { Text("Test connection") }
            Spacer(modifier = Modifier.width(8.dp))
            TextButton(onClick = { viewModel.removeGeminiApiKey() }) { Text("Remove") }
        }
        state.geminiTestResultMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) }

        Spacer(modifier = Modifier.height(16.dp))
        Text("Backup", style = MaterialTheme.typography.titleMedium)
        Button(onClick = { viewModel.backupNow() }) { Text("Back up now (Local Only)") }
        state.backupResultMessage?.let { Text(it, style = MaterialTheme.typography.bodySmall) }
    }
}
