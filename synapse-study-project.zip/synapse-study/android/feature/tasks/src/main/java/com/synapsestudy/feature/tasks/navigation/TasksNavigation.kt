package com.synapsestudy.feature.tasks.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.synapsestudy.core.navigation.SynapseDestination
import com.synapsestudy.feature.tasks.TasksScreen

fun NavGraphBuilder.tasksGraph(navController: NavHostController) {
    composable(SynapseDestination.Tasks.route) {
        TasksScreen(onTaskClick = { task -> navController.navigate(SynapseDestination.TaskDetail.createRoute(task.id)) })
    }
}
