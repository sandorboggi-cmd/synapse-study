package com.synapsestudy.feature.tasks

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.synapsestudy.core.common.Ids
import com.synapsestudy.core.common.TimeProvider
import com.synapsestudy.core.database.dao.TaskDao
import com.synapsestudy.core.model.Task
import com.synapsestudy.core.model.TaskPriority
import com.synapsestudy.core.model.TaskType
import com.synapsestudy.feature.tasks.mapper.toDomain
import com.synapsestudy.feature.tasks.mapper.toEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import javax.inject.Inject

@HiltViewModel
class TasksViewModel @Inject constructor(
    private val taskDao: TaskDao,
    private val timeProvider: TimeProvider
) : ViewModel() {

    private val _filter = MutableStateFlow(TaskFilter())
    private val _uiState = MutableStateFlow(TasksUiState())
    val uiState: StateFlow<TasksUiState> = _uiState.asStateFlow()

    init {
        combine(taskDao.observeAll(), _filter) { entities, filter ->
            val domainTasks = entities.map { it.toDomain() }
                .filter { filter.showCompleted || !it.isCompleted }
                .filter { filter.subjectId == null || it.subjectId == filter.subjectId }
                .filter { filter.studyHubId == null || it.studyHubId == filter.studyHubId }
            TasksUiState(isLoading = false, tasks = domainTasks, filter = filter)
        }.onEach { _uiState.value = it }.launchIn(viewModelScope)
    }

    fun updateFilter(filter: TaskFilter) { _filter.value = filter }

    fun createTask(title: String, taskType: TaskType, priority: TaskPriority, dueAtEpochMillis: Long?) {
        viewModelScope.launch {
            val now = timeProvider.nowEpochMillis()
            val task = Task(
                id = Ids.newId(), title = title, notes = null, dueAtEpochMillis = dueAtEpochMillis,
                scheduledAtEpochMillis = null, recurrenceRule = null, priority = priority, taskType = taskType,
                tags = emptyList(), iconKey = null, colorHex = null, estimatedMinutes = null,
                actualFocusMinutes = 0, isCompleted = false, studyHubId = null, examId = null, subjectId = null,
                createdAt = now, updatedAt = now
            )
            taskDao.upsert(task.toEntity())
        }
    }

    fun toggleCompleted(task: Task) {
        viewModelScope.launch { taskDao.setCompleted(task.id, !task.isCompleted, timeProvider.nowEpochMillis()) }
    }

    fun archiveTask(task: Task) { viewModelScope.launch { taskDao.archive(task.id, timeProvider.nowEpochMillis()) } }
    fun deleteTask(task: Task) { viewModelScope.launch { taskDao.delete(task.toEntity()) } }
}
