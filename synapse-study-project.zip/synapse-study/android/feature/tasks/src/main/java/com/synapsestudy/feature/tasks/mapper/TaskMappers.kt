package com.synapsestudy.feature.tasks.mapper

import com.synapsestudy.core.database.entity.TaskEntity
import com.synapsestudy.core.model.Task
import com.synapsestudy.core.model.TaskPriority
import com.synapsestudy.core.model.TaskType

fun TaskEntity.toDomain(): Task = Task(
    id = id, title = title, notes = notes, dueAtEpochMillis = dueAtEpochMillis,
    scheduledAtEpochMillis = scheduledAtEpochMillis, recurrenceRule = recurrenceRule,
    priority = TaskPriority.valueOf(priority), taskType = TaskType.valueOf(taskType),
    tags = if (tagsCsv.isBlank()) emptyList() else tagsCsv.split(","),
    iconKey = iconKey, colorHex = colorHex, estimatedMinutes = estimatedMinutes,
    actualFocusMinutes = actualFocusMinutes, isCompleted = isCompleted,
    studyHubId = studyHubId, examId = examId, subjectId = subjectId,
    createdAt = createdAt, updatedAt = updatedAt, schemaVersion = schemaVersion, isArchived = isArchived
)

fun Task.toEntity(): TaskEntity = TaskEntity(
    id = id, title = title, notes = notes, dueAtEpochMillis = dueAtEpochMillis,
    scheduledAtEpochMillis = scheduledAtEpochMillis, recurrenceRule = recurrenceRule,
    priority = priority.name, taskType = taskType.name, tagsCsv = tags.joinToString(","),
    iconKey = iconKey, colorHex = colorHex, estimatedMinutes = estimatedMinutes,
    actualFocusMinutes = actualFocusMinutes, isCompleted = isCompleted,
    studyHubId = studyHubId, examId = examId, subjectId = subjectId,
    createdAt = createdAt, updatedAt = updatedAt, schemaVersion = schemaVersion, isArchived = isArchived
)
