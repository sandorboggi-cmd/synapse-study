package com.synapsestudy.feature.tasks

import com.synapsestudy.core.model.Task

data class TasksUiState(val isLoading: Boolean = true, val tasks: List<Task> = emptyList(), val filter: TaskFilter = TaskFilter())
data class TaskFilter(val showCompleted: Boolean = false, val subjectId: String? = null, val studyHubId: String? = null)
