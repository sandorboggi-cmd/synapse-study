package com.synapsestudy.feature.tasks

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.hilt.navigation.compose.hiltViewModel
import com.synapsestudy.core.model.Task
import com.synapsestudy.core.model.TaskPriority
import com.synapsestudy.core.model.TaskType
import com.synapsestudy.core.ui.components.SynapseEmptyState

@Composable
fun TasksScreen(onTaskClick: (Task) -> Unit, viewModel: TasksViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()
    var showCreateDialog by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            FloatingActionButton(onClick = { showCreateDialog = true }) { Icon(Icons.Filled.Add, contentDescription = "New task") }
        }
    ) { padding ->
        if (state.tasks.isEmpty()) {
            SynapseEmptyState("No tasks yet. Tap + to add your first task.", modifier = Modifier.padding(padding))
        } else {
            LazyColumn(modifier = Modifier.padding(padding).fillMaxSize()) {
                items(state.tasks, key = { it.id }) { task ->
                    ListItem(
                        headlineContent = { Text(task.title) },
                        supportingContent = { Text("${'$'}{task.taskType} - ${'$'}{task.priority}") },
                        leadingContent = { Checkbox(checked = task.isCompleted, onCheckedChange = { viewModel.toggleCompleted(task) }) },
                        modifier = Modifier.clickable { onTaskClick(task) }
                    )
                }
            }
        }
    }

    if (showCreateDialog) {
        var title by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("New task") },
            text = { Column { OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Title") }) } },
            confirmButton = {
                TextButton(onClick = {
                    if (title.isNotBlank()) {
                        viewModel.createTask(title, TaskType.REVISION, TaskPriority.MEDIUM, null)
                        showCreateDialog = false
                    }
                }) { Text("Create") }
            },
            dismissButton = { TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") } }
        )
    }
}
