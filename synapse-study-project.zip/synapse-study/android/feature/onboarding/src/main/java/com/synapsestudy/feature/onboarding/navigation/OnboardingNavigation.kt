package com.synapsestudy.feature.onboarding.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.synapsestudy.core.navigation.SynapseDestination
import com.synapsestudy.feature.onboarding.OnboardingScreen

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
fun NavGraphBuilder.onboardingGraph(navController: NavHostController) {
    composable(SynapseDestination.Onboarding.route) {
        OnboardingScreen(onContinue = {
            navController.navigate(SynapseDestination.Today.route) {
                popUpTo(SynapseDestination.Onboarding.route) { inclusive = true }
            }
        })
    }
}
