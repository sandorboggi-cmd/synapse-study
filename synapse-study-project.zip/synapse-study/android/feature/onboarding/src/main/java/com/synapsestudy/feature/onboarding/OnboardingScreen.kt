package com.synapsestudy.feature.onboarding

import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

/**
 * Minimal single-user onboarding: explains SOURCE_ONLY default and Local
 * Only sync default, then proceeds to Today. No account creation, no
 * multi-user setup, per project scope.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
@Composable
fun OnboardingScreen(onContinue: () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text("Welcome to Synapse Study", style = MaterialTheme.typography.titleLarge)
        Spacer(modifier = Modifier.height(16.dp))
        Text("Your Study AI answers only from sources you select (SOURCE_ONLY mode). Everything stays on this device unless you turn on backup later.")
        Spacer(modifier = Modifier.height(24.dp))
        Button(onClick = onContinue) { Text("Get started") }
    }
}
