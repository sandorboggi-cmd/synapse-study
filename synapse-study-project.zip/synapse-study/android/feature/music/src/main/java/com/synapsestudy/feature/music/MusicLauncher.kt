package com.synapsestudy.feature.music

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import com.synapsestudy.core.model.MusicService

/**
 * Launches an external music app via Android intent using the saved
 * deep-link URI. No assumption of direct in-app playback control - if the
 * target app isn't installed, catches ActivityNotFoundException and
 * returns a clear fallback result instead of crashing.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
class MusicLauncher {
    fun launch(context: Context, deepLinkUri: String, service: MusicService): LaunchResult {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(deepLinkUri))
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
            LaunchResult.Success
        } catch (e: ActivityNotFoundException) {
            LaunchResult.AppNotInstalled(service)
        } catch (e: Exception) {
            LaunchResult.Error(e.message ?: "Unknown error launching music app")
        }
    }
}

sealed interface LaunchResult {
    data object Success : LaunchResult
    data class AppNotInstalled(val service: MusicService) : LaunchResult
    data class Error(val message: String) : LaunchResult
}
