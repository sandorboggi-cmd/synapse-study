package com.synapsestudy.feature.music

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.synapsestudy.core.common.Ids
import com.synapsestudy.core.common.TimeProvider
import com.synapsestudy.core.database.dao.MusicTargetDao
import com.synapsestudy.core.database.entity.MusicTargetEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import javax.inject.Inject

data class MusicUiState(val isLoading: Boolean = true, val targets: List<MusicTargetEntity> = emptyList())

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
@HiltViewModel
class MusicViewModel @Inject constructor(
    private val musicTargetDao: MusicTargetDao,
    private val timeProvider: TimeProvider
) : ViewModel() {
    private val _uiState = MutableStateFlow(MusicUiState())
    val uiState: StateFlow<MusicUiState> = _uiState.asStateFlow()

    init {
        musicTargetDao.observeAll()
            .onEach { targets -> _uiState.value = MusicUiState(isLoading = false, targets = targets) }
            .launchIn(viewModelScope)
    }

    fun saveMusicTarget(label: String, service: String, deepLinkUri: String) {
        viewModelScope.launch {
            val now = timeProvider.nowEpochMillis()
            musicTargetDao.upsert(
                MusicTargetEntity(
                    id = Ids.newId(), label = label, service = service, deepLinkUri = deepLinkUri,
                    createdAt = now, updatedAt = now, schemaVersion = 1, isArchived = false
                )
            )
        }
    }
}
