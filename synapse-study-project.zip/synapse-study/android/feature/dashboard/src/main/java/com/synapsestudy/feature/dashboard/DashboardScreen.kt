package com.synapsestudy.feature.dashboard

import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.synapsestudy.core.ui.components.SynapseCard
import com.synapsestudy.core.ui.components.SynapseLoadingIndicator

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
@Composable
fun DashboardScreen(viewModel: DashboardViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()

    if (state.isLoading) { SynapseLoadingIndicator(); return }

    LazyColumn(modifier = Modifier.fillMaxSize().padding(8.dp)) {
        items(state.cardOrder) { card ->
            when (card) {
                DashboardCard.NEXT_TASK -> SynapseCard(title = "Next task") { Text(state.nextTaskTitle ?: "No upcoming tasks") }
                DashboardCard.EXAM_COUNTDOWN -> SynapseCard(title = "Exam countdown") {
                    if (state.examCountdownDays != null) Text("${'$'}{state.examCountdownLabel}: ${'$'}{state.examCountdownDays} days")
                    else Text("No exam scheduled")
                }
                DashboardCard.RECENT_CHAT -> SynapseCard(title = "Resume Study AI chat") { Text(state.recentChatTitle ?: "No recent chats") }
                DashboardCard.RECENT_SOURCE -> SynapseCard(title = "Recently processed source") { Text(state.recentSourceName ?: "No sources yet") }
                DashboardCard.FOCUS_PROGRESS -> SynapseCard(title = "Focus progress") { Text("${'$'}{state.focusStreakDays} completed sessions") }
            }
        }
    }
}
