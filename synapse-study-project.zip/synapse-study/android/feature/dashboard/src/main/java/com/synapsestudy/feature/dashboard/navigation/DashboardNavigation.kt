package com.synapsestudy.feature.dashboard.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.synapsestudy.core.navigation.SynapseDestination
import com.synapsestudy.feature.dashboard.DashboardScreen

fun NavGraphBuilder.dashboardGraph(navController: NavHostController) {
    composable(SynapseDestination.Today.route) { DashboardScreen() }
}
