package com.synapsestudy.feature.dashboard

data class DashboardUiState(
    val isLoading: Boolean = true,
    val nextTaskTitle: String? = null,
    val examCountdownDays: Int? = null,
    val examCountdownLabel: String? = null,
    val recentChatTitle: String? = null,
    val recentSourceName: String? = null,
    val focusStreakDays: Int = 0,
    val cardOrder: List<DashboardCard> = DashboardCard.entries
)

enum class DashboardCard { NEXT_TASK, EXAM_COUNTDOWN, RECENT_CHAT, RECENT_SOURCE, FOCUS_PROGRESS }
