package com.synapsestudy.feature.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.synapsestudy.core.common.TimeProvider
import com.synapsestudy.core.database.dao.ChatDao
import com.synapsestudy.core.database.dao.ExamDao
import com.synapsestudy.core.database.dao.FocusSessionDao
import com.synapsestudy.core.database.dao.SourceDao
import com.synapsestudy.core.database.dao.TaskDao
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import java.util.concurrent.TimeUnit
import javax.inject.Inject

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
@HiltViewModel
class DashboardViewModel @Inject constructor(
    private val taskDao: TaskDao,
    private val examDao: ExamDao,
    private val chatDao: ChatDao,
    private val sourceDao: SourceDao,
    private val focusSessionDao: FocusSessionDao,
    private val timeProvider: TimeProvider
) : ViewModel() {

    private val _uiState = MutableStateFlow(DashboardUiState())
    val uiState: StateFlow<DashboardUiState> = _uiState.asStateFlow()

    init {
        combine(
            taskDao.observeAll(), examDao.observeAll(), chatDao.observeAll(),
            sourceDao.observeAll(), focusSessionDao.observeAll()
        ) { tasks, exams, chats, sources, sessions ->
            val nextTask = tasks.filter { !it.isCompleted }.minByOrNull { it.dueAtEpochMillis ?: Long.MAX_VALUE }
            val nextExam = exams.minByOrNull { it.examDateEpochMillis }
            val daysUntilExam = nextExam?.let {
                TimeUnit.MILLISECONDS.toDays(it.examDateEpochMillis - timeProvider.nowEpochMillis()).toInt()
            }
            DashboardUiState(
                isLoading = false,
                nextTaskTitle = nextTask?.title,
                examCountdownDays = daysUntilExam,
                examCountdownLabel = nextExam?.name,
                recentChatTitle = chats.firstOrNull()?.title,
                recentSourceName = sources.firstOrNull()?.displayName,
                focusStreakDays = sessions.count { it.wasCompleted }
            )
        }.onEach { _uiState.value = it }.launchIn(viewModelScope)
    }
}
