package com.synapsestudy.feature.wellness.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.synapsestudy.core.navigation.SynapseDestination
import com.synapsestudy.feature.wellness.WellnessScreen

/**
 * Conditionally registered by the caller (only added to the NavGraph when
 * wellnessEnabled == true), so the destination itself doesn't exist when
 * the module is disabled - satisfying "no Wellness destination when
 * disabled" at the navigation-graph level, not just via a hidden button.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
fun NavGraphBuilder.wellnessGraph(navController: NavHostController) {
    composable(SynapseDestination.Wellness.route) { WellnessScreen() }
}
