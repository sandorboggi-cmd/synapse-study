package com.synapsestudy.feature.wellness

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.synapsestudy.core.common.Ids
import com.synapsestudy.core.common.TimeProvider
import com.synapsestudy.core.database.dao.WellnessLogDao
import com.synapsestudy.core.database.dao.WellnessProfileDao
import com.synapsestudy.core.database.entity.WellnessLogEntity
import com.synapsestudy.core.database.entity.WellnessProfileEntity
import com.synapsestudy.core.security.EncryptedKeyStore
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import javax.inject.Inject

data class WellnessUiState(
    val companionType: String = "NEUTRAL",
    val affirmation: String = "You're doing okay - one step at a time.",
    val lastMoodScore: Int? = null
)

/**
 * Fully isolated wellness module. Reflection text is encrypted via
 * EncryptedKeyStore.saveWellnessReflection (not plain Room text) per
 * spec's "sensitive wellness reflection text" encryption requirement.
 * No medical diagnosis language, no shame/guilt language anywhere in
 * this module's copy - affirmations and prompts are deliberately gentle.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
@HiltViewModel
class WellnessViewModel @Inject constructor(
    private val wellnessProfileDao: WellnessProfileDao,
    private val wellnessLogDao: WellnessLogDao,
    private val encryptedKeyStore: EncryptedKeyStore,
    private val timeProvider: TimeProvider
) : ViewModel() {

    private val _uiState = MutableStateFlow(WellnessUiState())
    val uiState: StateFlow<WellnessUiState> = _uiState.asStateFlow()

    fun logMoodAndReflection(moodScore: Int, reflectionText: String?) {
        viewModelScope.launch {
            val now = timeProvider.nowEpochMillis()
            val logId = Ids.newId()
            wellnessLogDao.upsert(
                WellnessLogEntity(
                    id = logId, moodScore = moodScore, reflectionTextEncrypted = null,
                    hydrationLogged = false, breathingExerciseKey = null,
                    createdAt = now, updatedAt = now, schemaVersion = 1, isArchived = false
                )
            )
            if (!reflectionText.isNullOrBlank()) {
                encryptedKeyStore.saveWellnessReflection(logId, reflectionText)
            }
            _uiState.value = _uiState.value.copy(lastMoodScore = moodScore)
        }
    }

    fun setCompanion(companionType: String) {
        viewModelScope.launch {
            val now = timeProvider.nowEpochMillis()
            wellnessProfileDao.upsert(
                WellnessProfileEntity(
                    id = "singleton-wellness-profile", isEnabled = true, companionType = companionType,
                    pronounPreference = null, createdAt = now, updatedAt = now, schemaVersion = 1, isArchived = false
                )
            )
            _uiState.value = _uiState.value.copy(companionType = companionType)
        }
    }
}
