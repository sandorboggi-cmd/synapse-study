package com.synapsestudy.feature.wellness.breathing

/**
 * Breathing exercise pattern definitions (phase durations in seconds).
 * Pure data, no Android dependency, reusable by a Compose animation later.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
enum class BreathingPhase { INHALE, HOLD, EXHALE, REST }

data class BreathingStep(val phase: BreathingPhase, val durationSeconds: Int)

object BreathingExercises {
    val boxBreathing = listOf(
        BreathingStep(BreathingPhase.INHALE, 4),
        BreathingStep(BreathingPhase.HOLD, 4),
        BreathingStep(BreathingPhase.EXHALE, 4),
        BreathingStep(BreathingPhase.REST, 4)
    )

    val pacedBreathing = listOf(
        BreathingStep(BreathingPhase.INHALE, 5),
        BreathingStep(BreathingPhase.EXHALE, 5)
    )

    val fourSevenEight = listOf(
        BreathingStep(BreathingPhase.INHALE, 4),
        BreathingStep(BreathingPhase.HOLD, 7),
        BreathingStep(BreathingPhase.EXHALE, 8)
    )
}
