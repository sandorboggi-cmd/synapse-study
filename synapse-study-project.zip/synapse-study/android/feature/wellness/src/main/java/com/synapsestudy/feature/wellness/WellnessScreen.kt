package com.synapsestudy.feature.wellness

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel

/**
 * Wellness screen. Only reachable when wellnessEnabled is true (checked
 * at the navigation graph registration point in core:navigation, not
 * inside this composable, so the whole route + its background work simply
 * doesn't exist when disabled).
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
@Composable
fun WellnessScreen(viewModel: WellnessViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()

    Column(modifier = Modifier.fillMaxSize().padding(16.dp)) {
        Text(state.affirmation, style = MaterialTheme.typography.titleMedium)
        Spacer(modifier = Modifier.height(16.dp))
        Text("Companion: ${'$'}{state.companionType}")
        Row {
            listOf("PUPPY", "UNICORN", "NEUTRAL").forEach { type ->
                FilterChip(
                    selected = state.companionType == type,
                    onClick = { viewModel.setCompanion(type) },
                    label = { Text(type) },
                    modifier = Modifier.padding(4.dp)
                )
            }
        }
        Spacer(modifier = Modifier.height(16.dp))
        Text("How are you feeling today?")
        Row {
            (1..5).forEach { score ->
                TextButton(onClick = { viewModel.logMoodAndReflection(score, null) }) { Text(score.toString()) }
            }
        }
    }
}
