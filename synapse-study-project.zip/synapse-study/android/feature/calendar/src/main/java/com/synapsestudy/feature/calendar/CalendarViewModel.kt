package com.synapsestudy.feature.calendar

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.synapsestudy.core.common.Ids
import com.synapsestudy.core.common.TimeProvider
import com.synapsestudy.core.database.dao.CalendarEventDao
import com.synapsestudy.core.database.entity.CalendarEventEntity
import dagger.hilt.android.lifecycle.HiltViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.launchIn
import kotlinx.coroutines.flow.onEach
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit
import javax.inject.Inject

enum class CalendarView { AGENDA, DAY, WEEK, MONTH }

data class CalendarUiState(
    val isLoading: Boolean = true, val view: CalendarView = CalendarView.WEEK,
    val events: List<CalendarEventEntity> = emptyList(), val hasSchedulingConflict: Boolean = false
)

@HiltViewModel
class CalendarViewModel @Inject constructor(
    private val calendarEventDao: CalendarEventDao,
    private val timeProvider: TimeProvider
) : ViewModel() {

    private val _view = MutableStateFlow(CalendarView.WEEK)
    private val _uiState = MutableStateFlow(CalendarUiState())
    val uiState: StateFlow<CalendarUiState> = _uiState.asStateFlow()

    init {
        _view.flatMapLatest { view ->
            val now = timeProvider.nowEpochMillis()
            val rangeMillis = when (view) {
                CalendarView.DAY -> TimeUnit.DAYS.toMillis(1)
                CalendarView.WEEK, CalendarView.AGENDA -> TimeUnit.DAYS.toMillis(7)
                CalendarView.MONTH -> TimeUnit.DAYS.toMillis(31)
            }
            calendarEventDao.observeInRange(now - rangeMillis, now + rangeMillis)
        }.onEach { events ->
            val conflict = events.zipWithNext().any { (a, b) -> a.endAtEpochMillis > b.startAtEpochMillis }
            _uiState.value = CalendarUiState(isLoading = false, view = _view.value, events = events, hasSchedulingConflict = conflict)
        }.launchIn(viewModelScope)
    }

    fun setView(view: CalendarView) { _view.value = view }

    fun createEvent(title: String, startAt: Long, endAt: Long) {
        viewModelScope.launch {
            val now = timeProvider.nowEpochMillis()
            calendarEventDao.upsert(
                CalendarEventEntity(
                    id = Ids.newId(), title = title, startAtEpochMillis = startAt, endAtEpochMillis = endAt,
                    relatedTaskId = null, relatedExamId = null, isUserPersonalEvent = true,
                    createdAt = now, updatedAt = now, schemaVersion = 1, isArchived = false
                )
            )
        }
    }
}
