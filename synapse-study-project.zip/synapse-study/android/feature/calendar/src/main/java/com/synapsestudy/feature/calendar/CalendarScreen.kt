package com.synapsestudy.feature.calendar

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import com.synapsestudy.core.ui.components.SynapseEmptyState

@Composable
fun CalendarScreen(viewModel: CalendarViewModel = hiltViewModel()) {
    val state by viewModel.uiState.collectAsState()

    Column(modifier = Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = state.view.ordinal) {
            CalendarView.entries.forEach { view ->
                Tab(selected = state.view == view, onClick = { viewModel.setView(view) }, text = { Text(view.name) })
            }
        }
        if (state.hasSchedulingConflict) {
            Text("Scheduling conflict detected in this range", modifier = Modifier.padding(8.dp), color = MaterialTheme.colorScheme.error)
        }
        if (state.events.isEmpty()) {
            SynapseEmptyState("No events in this range")
        } else {
            LazyColumn {
                items(state.events, key = { it.id }) { event ->
                    ListItem(headlineContent = { Text(event.title) }, supportingContent = { Text("${'$'}{event.startAtEpochMillis} - ${'$'}{event.endAtEpochMillis}") })
                }
            }
        }
    }
}
