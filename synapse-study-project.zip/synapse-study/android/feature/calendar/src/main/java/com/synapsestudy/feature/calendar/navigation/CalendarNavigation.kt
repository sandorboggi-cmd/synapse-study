package com.synapsestudy.feature.calendar.navigation

import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.composable
import com.synapsestudy.core.navigation.SynapseDestination
import com.synapsestudy.feature.calendar.CalendarScreen

fun NavGraphBuilder.calendarGraph(navController: NavHostController) {
    composable(SynapseDestination.Calendar.route) { CalendarScreen() }
}
