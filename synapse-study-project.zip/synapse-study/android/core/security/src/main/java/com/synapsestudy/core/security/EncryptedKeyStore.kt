package com.synapsestudy.core.security

import android.content.Context
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject
import javax.inject.Singleton

/**
 * Android Keystore-backed encrypted storage, scoped ONLY to the Gemini
 * API key and wellness reflection text - the two categories of genuinely
 * sensitive data in this app. Everything else (theme, task titles, etc.)
 * lives in plain Room/DataStore since it isn't sensitive. Key preview is
 * always masked (never returns the raw key back to the UI) so Settings
 * can display "confirmed saved" without re-exposing the secret.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
@Singleton
class EncryptedKeyStore @Inject constructor(@ApplicationContext private val context: Context) {

    private val masterKey = MasterKey.Builder(context)
        .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
        .build()

    private val prefs = EncryptedSharedPreferences.create(
        context, "synapse_secure_prefs", masterKey,
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun saveGeminiApiKey(rawKey: String) { prefs.edit().putString(KEY_GEMINI_API_KEY, rawKey).apply() }

    fun getGeminiApiKey(): String? = prefs.getString(KEY_GEMINI_API_KEY, null)

    fun hasGeminiApiKey(): Boolean = !getGeminiApiKey().isNullOrBlank()

    fun removeGeminiApiKey() { prefs.edit().remove(KEY_GEMINI_API_KEY).apply() }

    fun getMaskedKeyPreview(): String? {
        val key = getGeminiApiKey() ?: return null
        if (key.length <= 6) return "••••••"
        return "${'$'}{key.take(4)}••••${'$'}{key.takeLast(2)}"
    }

    fun saveWellnessReflection(logId: String, reflectionText: String) {
        prefs.edit().putString("${'$'}WELLNESS_REFLECTION_PREFIX${'$'}logId", reflectionText).apply()
    }

    fun getWellnessReflection(logId: String): String? = prefs.getString("${'$'}WELLNESS_REFLECTION_PREFIX${'$'}logId", null)

    companion object {
        private const val KEY_GEMINI_API_KEY = "gemini_api_key"
        private const val WELLNESS_REFLECTION_PREFIX = "wellness_reflection_"
    }
}
