package com.synapsestudy.core.navigation

/**
 * The 5 phone bottom-nav tabs. Wellness is deliberately excluded from
 * the primary tab bar (reachable via Settings instead) per spec, and only
 * added to the nav graph at all when the wellness module is enabled.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
data class BottomNavItem(val destination: SynapseDestination, val label: String)

val bottomNavItems = listOf(
    BottomNavItem(SynapseDestination.Today, "Today"),
    BottomNavItem(SynapseDestination.Tasks, "Tasks"),
    BottomNavItem(SynapseDestination.StudyHub, "Hubs"),
    BottomNavItem(SynapseDestination.StudyAi, "Study AI"),
    BottomNavItem(SynapseDestination.Settings, "Settings")
)
