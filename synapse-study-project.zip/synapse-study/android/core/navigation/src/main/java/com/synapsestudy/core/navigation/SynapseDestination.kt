package com.synapsestudy.core.navigation

/**
 * Central destination registry. Detail routes take an ID argument via
 * createRoute() so every feature module builds nav routes consistently.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
sealed class SynapseDestination(val route: String) {
    data object Onboarding : SynapseDestination("onboarding")
    data object Today : SynapseDestination("today")
    data object Tasks : SynapseDestination("tasks")
    data object TaskDetail : SynapseDestination("tasks/{taskId}") {
        fun createRoute(taskId: String) = "tasks/${'$'}taskId"
    }
    data object Calendar : SynapseDestination("calendar")
    data object StudyHub : SynapseDestination("studyhub")
    data object StudyHubDetail : SynapseDestination("studyhub/{hubId}") {
        fun createRoute(hubId: String) = "studyhub/${'$'}hubId"
    }
    data object Library : SynapseDestination("library")
    data object SourceViewer : SynapseDestination("source/{sourceId}") {
        fun createRoute(sourceId: String) = "source/${'$'}sourceId"
    }
    data object StudyAi : SynapseDestination("studyai")
    data object Assets : SynapseDestination("assets")
    data object Focus : SynapseDestination("focus")
    data object Search : SynapseDestination("search")
    data object Settings : SynapseDestination("settings")
    data object Wellness : SynapseDestination("wellness")
}
