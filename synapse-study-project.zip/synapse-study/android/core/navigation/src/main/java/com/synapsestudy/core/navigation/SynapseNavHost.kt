package com.synapsestudy.core.navigation

import androidx.compose.foundation.layout.padding
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.navigation.NavGraphBuilder
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.currentBackStackEntryAsState

/**
 * Root NavHost + bottom nav bar shell. Feature modules register their own
 * routes via extension functions on NavGraphBuilder (e.g. dashboardGraph,
 * tasksGraph) which the app module composes together - core:navigation
 * itself never depends on feature modules, avoiding a circular dependency.
 *
 * This function accepts a lambda so app module supplies the actual feature
 * graphs without core:navigation needing to know about them.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
@Composable
fun SynapseNavHost(
    navController: NavHostController,
    startDestination: String = SynapseDestination.Today.route,
    graphBuilder: NavGraphBuilder.() -> Unit = {}
) {
    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    Scaffold(
        bottomBar = {
            NavigationBar {
                bottomNavItems.forEach { item ->
                    NavigationBarItem(
                        selected = currentRoute == item.destination.route,
                        onClick = {
                            navController.navigate(item.destination.route) {
                                launchSingleTop = true
                            }
                        },
                        icon = {},
                        label = { Text(item.label) }
                    )
                }
            }
        }
    ) { padding ->
        NavHost(
            navController = navController,
            startDestination = startDestination,
            modifier = androidx.compose.ui.Modifier.padding(padding),
            builder = graphBuilder
        )
    }
}
