package com.synapsestudy.core.datastore

import android.content.Context
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import dagger.hilt.android.qualifiers.ApplicationContext
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import javax.inject.Inject
import javax.inject.Singleton

private val Context.dataStore by preferencesDataStore(name = "synapse_study_prefs")

/**
 * Non-sensitive app preferences only (theme, AI mode, sync mode, wellness
 * toggle, dashboard card order). The Gemini API key and wellness
 * reflections deliberately never live here - see core:security.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
@Singleton
class UserPreferencesDataStore @Inject constructor(@ApplicationContext private val context: Context) {

    private object Keys {
        val THEME_MODE = stringPreferencesKey("theme_mode")
        val AI_MODE = stringPreferencesKey("ai_mode")
        val SYNC_MODE = stringPreferencesKey("sync_mode")
        val WELLNESS_ENABLED = booleanPreferencesKey("wellness_enabled")
        val DASHBOARD_CARD_ORDER = stringPreferencesKey("dashboard_card_order")
    }

    val themeMode: Flow<String> = context.dataStore.data.map { it[Keys.THEME_MODE] ?: "SYSTEM" }
    val aiMode: Flow<String> = context.dataStore.data.map { it[Keys.AI_MODE] ?: "SOURCE_ONLY" }
    val syncMode: Flow<String> = context.dataStore.data.map { it[Keys.SYNC_MODE] ?: "LOCAL_ONLY" }
    val wellnessEnabled: Flow<Boolean> = context.dataStore.data.map { it[Keys.WELLNESS_ENABLED] ?: false }
    val dashboardCardOrderCsv: Flow<String> = context.dataStore.data.map { it[Keys.DASHBOARD_CARD_ORDER] ?: "" }

    suspend fun setThemeMode(mode: String) { context.dataStore.edit { it[Keys.THEME_MODE] = mode } }
    suspend fun setAiMode(mode: String) { context.dataStore.edit { it[Keys.AI_MODE] = mode } }
    suspend fun setSyncMode(mode: String) { context.dataStore.edit { it[Keys.SYNC_MODE] = mode } }
    suspend fun setWellnessEnabled(enabled: Boolean) { context.dataStore.edit { it[Keys.WELLNESS_ENABLED] = enabled } }
    suspend fun setDashboardCardOrder(csv: String) { context.dataStore.edit { it[Keys.DASHBOARD_CARD_ORDER] = csv } }
}
