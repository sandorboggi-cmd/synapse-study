package com.synapsestudy.core.designsystem.theme

import androidx.compose.ui.graphics.Color

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
val SynapsePrimary = Color(0xFF3D5AFE)
val SynapseSecondary = Color(0xFF00BFA5)
val SynapseBackgroundLight = Color(0xFFFAFAFA)
val SynapseBackgroundDark = Color(0xFF121212)
val SynapseBackgroundAmoled = Color(0xFF000000)
val SynapseError = Color(0xFFB00020)
