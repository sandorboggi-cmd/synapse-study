package com.synapsestudy.core.designsystem.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable

/**
 * Material 3 theme with Light/Dark/System/AMOLED support. AMOLED uses
 * pure black background for battery savings on OLED screens during long
 * study sessions, as distinct from the standard dark scheme.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
private val LightColors = lightColorScheme(primary = SynapsePrimary, secondary = SynapseSecondary, background = SynapseBackgroundLight, error = SynapseError)
private val DarkColors = darkColorScheme(primary = SynapsePrimary, secondary = SynapseSecondary, background = SynapseBackgroundDark, error = SynapseError)
private val AmoledColors = darkColorScheme(primary = SynapsePrimary, secondary = SynapseSecondary, background = SynapseBackgroundAmoled, surface = SynapseBackgroundAmoled, error = SynapseError)

enum class SynapseThemeMode { LIGHT, DARK, SYSTEM, AMOLED }

@Composable
fun SynapseStudyTheme(
    themeMode: SynapseThemeMode = SynapseThemeMode.SYSTEM,
    content: @Composable () -> Unit
) {
    val colorScheme = when (themeMode) {
        SynapseThemeMode.LIGHT -> LightColors
        SynapseThemeMode.DARK -> DarkColors
        SynapseThemeMode.AMOLED -> AmoledColors
        SynapseThemeMode.SYSTEM -> if (isSystemInDarkTheme()) DarkColors else LightColors
    }
    MaterialTheme(colorScheme = colorScheme, typography = SynapseTypography, content = content)
}
