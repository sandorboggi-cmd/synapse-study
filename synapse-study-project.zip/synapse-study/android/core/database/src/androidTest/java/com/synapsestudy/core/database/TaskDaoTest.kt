package com.synapsestudy.core.database

import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import com.synapsestudy.core.database.entity.TaskEntity
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

/**
 * Instrumented test requiring a device/emulator - NOT run in this
 * environment (no emulator available). Runnable via
 * ./gradlew :core:database:connectedAndroidTest.
 *
 * STATUS: Generated, statically reviewed, not run.
 */
@RunWith(AndroidJUnit4::class)
class TaskDaoTest {
    private lateinit var db: SynapseStudyDatabase

    @Before
    fun setUp() {
        db = Room.inMemoryDatabaseBuilder(ApplicationProvider.getApplicationContext(), SynapseStudyDatabase::class.java)
            .allowMainThreadQueries()
            .build()
    }

    @After
    fun tearDown() { db.close() }

    @Test
    fun insertAndRetrieveTask() = runBlocking {
        val task = TaskEntity(
            id = "t1", title = "Review Krebs cycle", notes = null, dueAtEpochMillis = null,
            scheduledAtEpochMillis = null, recurrenceRule = null, priority = "HIGH", taskType = "REVISION",
            tagsCsv = "biology", iconKey = null, colorHex = null, estimatedMinutes = 30, actualFocusMinutes = 0,
            isCompleted = false, studyHubId = null, examId = null, subjectId = null,
            createdAt = 0L, updatedAt = 0L
        )
        db.taskDao().upsert(task)
        val tasks = db.taskDao().observeAll().first()
        assertEquals(1, tasks.size)
        assertEquals("Review Krebs cycle", tasks.first().title)
    }

    @Test
    fun setCompletedUpdatesFlag() = runBlocking {
        val task = TaskEntity(
            id = "t2", title = "Practice problems", notes = null, dueAtEpochMillis = null,
            scheduledAtEpochMillis = null, recurrenceRule = null, priority = "MEDIUM", taskType = "PRACTICE",
            tagsCsv = "", iconKey = null, colorHex = null, estimatedMinutes = null, actualFocusMinutes = 0,
            isCompleted = false, studyHubId = null, examId = null, subjectId = null,
            createdAt = 0L, updatedAt = 0L
        )
        db.taskDao().upsert(task)
        db.taskDao().setCompleted("t2", true, 100L)
        val updated = db.taskDao().getById("t2")
        assertEquals(true, updated?.isCompleted)
    }
}
