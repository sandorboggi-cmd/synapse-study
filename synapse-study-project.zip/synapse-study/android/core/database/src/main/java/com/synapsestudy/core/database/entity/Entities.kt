package com.synapsestudy.core.database.entity

import androidx.room.Entity
import androidx.room.Fts4
import androidx.room.PrimaryKey

/**
 * Room entities. Field names deliberately mirror core:model domain classes
 * so mapper functions (e.g. feature:tasks TaskMappers.kt) are simple 1:1
 * conversions. Tags/CSV fields chosen intentionally for a single-user
 * local DB rather than introducing join tables for simple list fields.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */

@Entity(tableName = "tasks")
data class TaskEntity(
    @PrimaryKey val id: String,
    val title: String,
    val notes: String?,
    val dueAtEpochMillis: Long?,
    val scheduledAtEpochMillis: Long?,
    val recurrenceRule: String?,
    val priority: String,
    val taskType: String,
    val tagsCsv: String,
    val iconKey: String?,
    val colorHex: String?,
    val estimatedMinutes: Int?,
    val actualFocusMinutes: Int,
    val isCompleted: Boolean,
    val studyHubId: String?,
    val examId: String?,
    val subjectId: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "subjects")
data class SubjectEntity(
    @PrimaryKey val id: String,
    val name: String,
    val colorHex: String,
    val iconKey: String,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "exams")
data class ExamEntity(
    @PrimaryKey val id: String,
    val subjectId: String?,
    val name: String,
    val examDateEpochMillis: Long,
    val notes: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "study_hubs")
data class StudyHubEntity(
    @PrimaryKey val id: String,
    val title: String,
    val subjectId: String?,
    val examId: String?,
    val colorHex: String,
    val iconKey: String,
    val readinessPercent: Int,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "calendar_events")
data class CalendarEventEntity(
    @PrimaryKey val id: String,
    val title: String,
    val startAtEpochMillis: Long,
    val endAtEpochMillis: Long,
    val relatedTaskId: String?,
    val relatedExamId: String?,
    val isUserPersonalEvent: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "sources")
data class SourceEntity(
    @PrimaryKey val id: String,
    val displayName: String,
    val sourceType: String,
    val originalFileUri: String?,
    val processingState: String,
    val currentVersionId: String?,
    val isAvailableOffline: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "source_versions")
data class SourceVersionEntity(
    @PrimaryKey val id: String,
    val sourceId: String,
    val versionNumber: Int,
    val extractedText: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "source_anchors")
data class SourceAnchorEntity(
    @PrimaryKey val id: String,
    val sourceVersionId: String,
    val pageNumber: Int?,
    val charStart: Int?,
    val charEnd: Int?,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "source_chunks")
data class SourceChunkEntity(
    @PrimaryKey val id: String,
    val sourceVersionId: String,
    val anchorId: String,
    val text: String,
    val chunkIndex: Int,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Fts4(contentEntity = SourceChunkEntity::class)
@Entity(tableName = "source_chunks_fts")
data class SourceChunkFtsEntity(
    val text: String
)

@Entity(tableName = "chats")
data class ChatEntity(
    @PrimaryKey val id: String,
    val title: String,
    val aiMode: String,
    val selectedSourceIdsCsv: String,
    val studyHubId: String?,
    val taskId: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "chat_messages")
data class ChatMessageEntity(
    @PrimaryKey val id: String,
    val chatId: String,
    val role: String,
    val content: String,
    val supportStatus: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "citation_anchors")
data class CitationAnchorEntity(
    @PrimaryKey val id: String,
    val chatMessageId: String,
    val sourceAnchorId: String,
    val evidenceChunkId: String,
    val quotedExcerpt: String,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "generated_assets")
data class GeneratedAssetEntity(
    @PrimaryKey val id: String,
    val title: String,
    val assetType: String,
    val sourceJobId: String?,
    val filePath: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "generation_jobs")
data class GenerationJobEntity(
    @PrimaryKey val id: String,
    val assetType: String,
    val status: String,
    val requestPayloadJson: String,
    val errorMessage: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "focus_presets")
data class FocusPresetEntity(
    @PrimaryKey val id: String,
    val name: String,
    val workMinutes: Int,
    val breakMinutes: Int,
    val cyclesBeforeLongBreak: Int,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "focus_sessions")
data class FocusSessionEntity(
    @PrimaryKey val id: String,
    val presetId: String?,
    val taskId: String?,
    val subjectId: String?,
    val examId: String?,
    val studyHubId: String?,
    val startedAtEpochMillis: Long,
    val endedAtEpochMillis: Long?,
    val actualFocusMinutes: Int,
    val wasCompleted: Boolean,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "music_targets")
data class MusicTargetEntity(
    @PrimaryKey val id: String,
    val label: String,
    val service: String,
    val deepLinkUri: String,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "notification_rules")
data class NotificationRuleEntity(
    @PrimaryKey val id: String,
    val channelKey: String,
    val isEnabled: Boolean,
    val quietHoursStart: String?,
    val quietHoursEnd: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "wellness_profiles")
data class WellnessProfileEntity(
    @PrimaryKey val id: String,
    val isEnabled: Boolean,
    val companionType: String,
    val pronounPreference: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)

@Entity(tableName = "wellness_logs")
data class WellnessLogEntity(
    @PrimaryKey val id: String,
    val moodScore: Int,
    val reflectionTextEncrypted: String?,
    val hydrationLogged: Boolean,
    val breathingExerciseKey: String?,
    val createdAt: Long,
    val updatedAt: Long,
    val schemaVersion: Int = 1,
    val isArchived: Boolean = false
)
