package com.synapsestudy.core.database

import androidx.room.Database
import androidx.room.RoomDatabase
import com.synapsestudy.core.database.dao.*
import com.synapsestudy.core.database.entity.*

/**
 * Single Room database for the whole app (personal single-user app, no
 * need for multiple DBs). exportSchema = true so schema JSON is generated
 * on first real Gradle build for future migration diffing.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
@Database(
    entities = [
        TaskEntity::class, SubjectEntity::class, ExamEntity::class, StudyHubEntity::class,
        CalendarEventEntity::class, SourceEntity::class, SourceVersionEntity::class,
        SourceAnchorEntity::class, SourceChunkEntity::class, SourceChunkFtsEntity::class,
        ChatEntity::class, ChatMessageEntity::class, CitationAnchorEntity::class,
        GeneratedAssetEntity::class, GenerationJobEntity::class, FocusPresetEntity::class,
        FocusSessionEntity::class, MusicTargetEntity::class, NotificationRuleEntity::class,
        WellnessProfileEntity::class, WellnessLogEntity::class
    ],
    version = 1,
    exportSchema = true
)
abstract class SynapseStudyDatabase : RoomDatabase() {
    abstract fun taskDao(): TaskDao
    abstract fun subjectDao(): SubjectDao
    abstract fun examDao(): ExamDao
    abstract fun studyHubDao(): StudyHubDao
    abstract fun calendarEventDao(): CalendarEventDao
    abstract fun sourceDao(): SourceDao
    abstract fun sourceVersionDao(): SourceVersionDao
    abstract fun sourceAnchorDao(): SourceAnchorDao
    abstract fun sourceChunkDao(): SourceChunkDao
    abstract fun chatDao(): ChatDao
    abstract fun chatMessageDao(): ChatMessageDao
    abstract fun citationAnchorDao(): CitationAnchorDao
    abstract fun generatedAssetDao(): GeneratedAssetDao
    abstract fun generationJobDao(): GenerationJobDao
    abstract fun focusPresetDao(): FocusPresetDao
    abstract fun focusSessionDao(): FocusSessionDao
    abstract fun musicTargetDao(): MusicTargetDao
    abstract fun notificationRuleDao(): NotificationRuleDao
    abstract fun wellnessProfileDao(): WellnessProfileDao
    abstract fun wellnessLogDao(): WellnessLogDao

    companion object {
        const val DATABASE_NAME = "synapse_study.db"
    }
}
