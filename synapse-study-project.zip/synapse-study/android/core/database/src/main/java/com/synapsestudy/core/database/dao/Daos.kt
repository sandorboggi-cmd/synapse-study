package com.synapsestudy.core.database.dao

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import com.synapsestudy.core.database.entity.*
import kotlinx.coroutines.flow.Flow

/**
 * DAOs. Every DAO exposes observeAll() as Flow for reactive ViewModels,
 * plus targeted mutation queries (setCompleted/archive) so ViewModels
 * don't have to read-modify-write whole entities for simple state flips.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */

@Dao
interface TaskDao {
    @Query("SELECT * FROM tasks WHERE isArchived = 0 ORDER BY dueAtEpochMillis ASC")
    fun observeAll(): Flow<List<TaskEntity>>

    @Query("SELECT * FROM tasks WHERE id = :id")
    suspend fun getById(id: String): TaskEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(task: TaskEntity)

    @Delete
    suspend fun delete(task: TaskEntity)

    @Query("UPDATE tasks SET isCompleted = :isCompleted, updatedAt = :updatedAt WHERE id = :id")
    suspend fun setCompleted(id: String, isCompleted: Boolean, updatedAt: Long)

    @Query("UPDATE tasks SET isArchived = 1, updatedAt = :updatedAt WHERE id = :id")
    suspend fun archive(id: String, updatedAt: Long)
}

@Dao
interface SubjectDao {
    @Query("SELECT * FROM subjects WHERE isArchived = 0")
    fun observeAll(): Flow<List<SubjectEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: SubjectEntity)
}

@Dao
interface ExamDao {
    @Query("SELECT * FROM exams WHERE isArchived = 0 ORDER BY examDateEpochMillis ASC")
    fun observeAll(): Flow<List<ExamEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ExamEntity)
}

@Dao
interface StudyHubDao {
    @Query("SELECT * FROM study_hubs WHERE isArchived = 0")
    fun observeAll(): Flow<List<StudyHubEntity>>
    @Query("SELECT * FROM study_hubs WHERE id = :id")
    suspend fun getById(id: String): StudyHubEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: StudyHubEntity)
    @Query("UPDATE study_hubs SET isArchived = 1, updatedAt = :updatedAt WHERE id = :id")
    suspend fun archive(id: String, updatedAt: Long)
}

@Dao
interface CalendarEventDao {
    @Query("SELECT * FROM calendar_events WHERE isArchived = 0 AND startAtEpochMillis BETWEEN :rangeStart AND :rangeEnd ORDER BY startAtEpochMillis ASC")
    fun observeInRange(rangeStart: Long, rangeEnd: Long): Flow<List<CalendarEventEntity>>
    @Query("SELECT * FROM calendar_events WHERE isArchived = 0 ORDER BY startAtEpochMillis ASC")
    fun observeAll(): Flow<List<CalendarEventEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: CalendarEventEntity)
}

@Dao
interface SourceDao {
    @Query("SELECT * FROM sources WHERE isArchived = 0 ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<SourceEntity>>
    @Query("SELECT * FROM sources WHERE id = :id")
    suspend fun getById(id: String): SourceEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: SourceEntity)
}

@Dao
interface SourceVersionDao {
    @Query("SELECT * FROM source_versions WHERE sourceId = :sourceId ORDER BY versionNumber DESC")
    fun observeBySource(sourceId: String): Flow<List<SourceVersionEntity>>
    @Query("SELECT * FROM source_versions WHERE id = :id")
    suspend fun getById(id: String): SourceVersionEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: SourceVersionEntity)
}

@Dao
interface SourceAnchorDao {
    @Query("SELECT * FROM source_anchors WHERE id = :id")
    suspend fun getById(id: String): SourceAnchorEntity?
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: SourceAnchorEntity)
}

@Dao
interface SourceChunkDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: SourceChunkEntity)

    @Query(
        """
        SELECT source_chunks.* FROM source_chunks_fts
        JOIN source_chunks ON source_chunks.id = source_chunks_fts.docid
        WHERE source_chunks_fts.text MATCH :ftsQuery
        AND source_chunks.sourceVersionId IN (:scopedSourceVersionIds)
        LIMIT :maxResults
        """
    )
    suspend fun searchFts(ftsQuery: String, scopedSourceVersionIds: List<String>, maxResults: Int): List<SourceChunkEntity>
}

@Dao
interface ChatDao {
    @Query("SELECT * FROM chats WHERE isArchived = 0 ORDER BY updatedAt DESC")
    fun observeAll(): Flow<List<ChatEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ChatEntity)
}

@Dao
interface ChatMessageDao {
    @Query("SELECT * FROM chat_messages WHERE chatId = :chatId ORDER BY createdAt ASC")
    fun observeByChat(chatId: String): Flow<List<ChatMessageEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: ChatMessageEntity)
}

@Dao
interface CitationAnchorDao {
    @Query("SELECT * FROM citation_anchors WHERE chatMessageId = :chatMessageId")
    fun observeByMessage(chatMessageId: String): Flow<List<CitationAnchorEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: CitationAnchorEntity)
}

@Dao
interface GeneratedAssetDao {
    @Query("SELECT * FROM generated_assets WHERE isArchived = 0 ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<GeneratedAssetEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: GeneratedAssetEntity)
}

@Dao
interface GenerationJobDao {
    @Query("SELECT * FROM generation_jobs WHERE isArchived = 0 ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<GenerationJobEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: GenerationJobEntity)
}

@Dao
interface FocusPresetDao {
    @Query("SELECT * FROM focus_presets WHERE isArchived = 0")
    fun observeAll(): Flow<List<FocusPresetEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: FocusPresetEntity)
}

@Dao
interface FocusSessionDao {
    @Query("SELECT * FROM focus_sessions WHERE isArchived = 0 ORDER BY startedAtEpochMillis DESC")
    fun observeAll(): Flow<List<FocusSessionEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: FocusSessionEntity)
}

@Dao
interface MusicTargetDao {
    @Query("SELECT * FROM music_targets WHERE isArchived = 0")
    fun observeAll(): Flow<List<MusicTargetEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: MusicTargetEntity)
}

@Dao
interface NotificationRuleDao {
    @Query("SELECT * FROM notification_rules WHERE isArchived = 0")
    fun observeAll(): Flow<List<NotificationRuleEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: NotificationRuleEntity)
}

@Dao
interface WellnessProfileDao {
    @Query("SELECT * FROM wellness_profiles LIMIT 1")
    fun observeProfile(): Flow<WellnessProfileEntity?>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: WellnessProfileEntity)
}

@Dao
interface WellnessLogDao {
    @Query("SELECT * FROM wellness_logs WHERE isArchived = 0 ORDER BY createdAt DESC")
    fun observeAll(): Flow<List<WellnessLogEntity>>
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(entity: WellnessLogEntity)
}
