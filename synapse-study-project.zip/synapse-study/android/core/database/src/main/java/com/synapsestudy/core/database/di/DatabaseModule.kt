package com.synapsestudy.core.database.di

import android.content.Context
import androidx.room.Room
import com.synapsestudy.core.database.SynapseStudyDatabase
import com.synapsestudy.core.database.dao.*
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.android.qualifiers.ApplicationContext
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
@Module
@InstallIn(SingletonComponent::class)
object DatabaseModule {

    @Provides
    @Singleton
    fun provideDatabase(@ApplicationContext context: Context): SynapseStudyDatabase =
        Room.databaseBuilder(context, SynapseStudyDatabase::class.java, SynapseStudyDatabase.DATABASE_NAME).build()

    @Provides fun provideTaskDao(db: SynapseStudyDatabase): TaskDao = db.taskDao()
    @Provides fun provideSubjectDao(db: SynapseStudyDatabase): SubjectDao = db.subjectDao()
    @Provides fun provideExamDao(db: SynapseStudyDatabase): ExamDao = db.examDao()
    @Provides fun provideStudyHubDao(db: SynapseStudyDatabase): StudyHubDao = db.studyHubDao()
    @Provides fun provideCalendarEventDao(db: SynapseStudyDatabase): CalendarEventDao = db.calendarEventDao()
    @Provides fun provideSourceDao(db: SynapseStudyDatabase): SourceDao = db.sourceDao()
    @Provides fun provideSourceVersionDao(db: SynapseStudyDatabase): SourceVersionDao = db.sourceVersionDao()
    @Provides fun provideSourceAnchorDao(db: SynapseStudyDatabase): SourceAnchorDao = db.sourceAnchorDao()
    @Provides fun provideSourceChunkDao(db: SynapseStudyDatabase): SourceChunkDao = db.sourceChunkDao()
    @Provides fun provideChatDao(db: SynapseStudyDatabase): ChatDao = db.chatDao()
    @Provides fun provideChatMessageDao(db: SynapseStudyDatabase): ChatMessageDao = db.chatMessageDao()
    @Provides fun provideCitationAnchorDao(db: SynapseStudyDatabase): CitationAnchorDao = db.citationAnchorDao()
    @Provides fun provideGeneratedAssetDao(db: SynapseStudyDatabase): GeneratedAssetDao = db.generatedAssetDao()
    @Provides fun provideGenerationJobDao(db: SynapseStudyDatabase): GenerationJobDao = db.generationJobDao()
    @Provides fun provideFocusPresetDao(db: SynapseStudyDatabase): FocusPresetDao = db.focusPresetDao()
    @Provides fun provideFocusSessionDao(db: SynapseStudyDatabase): FocusSessionDao = db.focusSessionDao()
    @Provides fun provideMusicTargetDao(db: SynapseStudyDatabase): MusicTargetDao = db.musicTargetDao()
    @Provides fun provideNotificationRuleDao(db: SynapseStudyDatabase): NotificationRuleDao = db.notificationRuleDao()
    @Provides fun provideWellnessProfileDao(db: SynapseStudyDatabase): WellnessProfileDao = db.wellnessProfileDao()
    @Provides fun provideWellnessLogDao(db: SynapseStudyDatabase): WellnessLogDao = db.wellnessLogDao()
}
