package com.synapsestudy.core.sync

import com.synapsestudy.core.common.SynapseResult

/**
 * Explicitly non-functional stub. Returns an honest "not configured"
 * error rather than pretending to sync - real implementation requires an
 * OAuth client ID from Google Cloud Console (see SETUP_REQUIRED.md item 3),
 * which only you can create.
 *
 * STATUS: Generated, statically reviewed, not compiled, intentionally
 * non-functional pending your OAuth setup.
 */
class GoogleDriveSyncProvider : PersonalSyncProvider {
    override val providerName: String = "Google Drive (not configured)"

    override suspend fun backupNow(): SynapseResult<BackupResult> =
        SynapseResult.Error("Google Drive sync is not configured. Add OAuth credentials in Settings > Sync first.")

    override suspend fun restoreLatest(): SynapseResult<Unit> =
        SynapseResult.Error("Google Drive sync is not configured.")
}
