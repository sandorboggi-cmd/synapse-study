package com.synapsestudy.core.sync

import com.synapsestudy.core.common.SynapseResult

/**
 * Sync provider abstraction. LOCAL_ONLY is the default and fully working
 * mode; GOOGLE_DRIVE requires external OAuth setup (see SETUP_REQUIRED.md)
 * and is honestly stubbed until you provide those credentials.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
interface PersonalSyncProvider {
    val providerName: String
    suspend fun backupNow(): SynapseResult<BackupResult>
    suspend fun restoreLatest(): SynapseResult<Unit>
}

data class BackupResult(val backupId: String, val timestampEpochMillis: Long)
