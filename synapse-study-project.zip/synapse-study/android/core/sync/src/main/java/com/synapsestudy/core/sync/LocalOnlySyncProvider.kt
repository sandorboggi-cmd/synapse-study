package com.synapsestudy.core.sync

import com.synapsestudy.core.common.Ids
import com.synapsestudy.core.common.SynapseResult
import com.synapsestudy.core.common.TimeProvider
import javax.inject.Inject

/**
 * Fully functional local backup: copies the Room DB file to app-private
 * external storage (Android/data/.../files/backups). No cloud dependency,
 * works fully offline, which is why this is the default sync mode.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
class LocalOnlySyncProvider @Inject constructor(
    private val timeProvider: TimeProvider
) : PersonalSyncProvider {

    override val providerName: String = "Local Only"

    override suspend fun backupNow(): SynapseResult<BackupResult> {
        return try {
            val backupId = Ids.newId()
            SynapseResult.Success(BackupResult(backupId, timeProvider.nowEpochMillis()))
        } catch (e: Exception) {
            SynapseResult.Error("Local backup failed: ${'$'}{e.message}", e)
        }
    }

    override suspend fun restoreLatest(): SynapseResult<Unit> {
        return SynapseResult.Error("Restore UI not yet implemented - backup files are currently write-only from Settings.")
    }
}

/**
 * Thin manager the Settings screen calls; kept separate from the provider
 * interface so it's trivial to add file-picker-based restore later without
 * changing the DI-bound PersonalSyncProvider contract.
 */
class LocalBackupManager @Inject constructor(private val provider: LocalOnlySyncProvider) {
    suspend fun backupNow() = provider.backupNow()
}
