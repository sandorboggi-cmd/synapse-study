package com.synapsestudy.core.sync.di

import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
@Module
@InstallIn(SingletonComponent::class)
object SyncModule {
    // LocalOnlySyncProvider and LocalBackupManager use @Inject constructor
    // directly and do not need explicit @Provides bindings here.
}
