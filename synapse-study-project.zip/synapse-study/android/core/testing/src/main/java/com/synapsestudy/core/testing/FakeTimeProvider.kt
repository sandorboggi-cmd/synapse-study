package com.synapsestudy.core.testing

import com.synapsestudy.core.common.TimeProvider

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
class FakeTimeProvider(private var currentMillis: Long = 1_735_000_000_000L) : TimeProvider {
    override fun nowEpochMillis(): Long = currentMillis
    fun advanceBy(millis: Long) { currentMillis += millis }
    fun setTo(millis: Long) { currentMillis = millis }
}
