package com.synapsestudy.core.ui.state

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
sealed interface UiState<out T> {
    data object Loading : UiState<Nothing>
    data class Loaded<T>(val data: T) : UiState<T>
    data class Empty(val message: String) : UiState<Nothing>
    data class ErrorState(val message: String) : UiState<Nothing>
}
