package com.synapsestudy.core.common

/**
 * Generic result wrapper used across every repository/provider boundary
 * in the app so error states are always explicit, never silent nulls or
 * uncaught exceptions bubbling into the UI layer.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
sealed interface SynapseResult<out T> {
    data class Success<T>(val data: T) : SynapseResult<T>
    data class Error(val message: String, val cause: Throwable? = null) : SynapseResult<Nothing>
    data object Loading : SynapseResult<Nothing>
}
