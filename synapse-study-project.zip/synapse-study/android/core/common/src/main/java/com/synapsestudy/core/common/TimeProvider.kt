package com.synapsestudy.core.common

/**
 * Abstraction over System.currentTimeMillis() so every module (dashboard
 * countdowns, task due dates, focus sessions) is deterministically
 * testable via FakeTimeProvider in core:testing.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
interface TimeProvider {
    fun nowEpochMillis(): Long
}

class SystemTimeProvider : TimeProvider {
    override fun nowEpochMillis(): Long = System.currentTimeMillis()
}
