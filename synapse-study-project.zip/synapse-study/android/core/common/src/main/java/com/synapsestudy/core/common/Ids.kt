package com.synapsestudy.core.common

import java.util.UUID

/**
 * Central ID generator. All domain entities use UUID strings as stable
 * IDs (never auto-increment ints), so local records survive export/import
 * and future sync merges without collisions.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */
object Ids {
    fun newId(): String = UUID.randomUUID().toString()
}
