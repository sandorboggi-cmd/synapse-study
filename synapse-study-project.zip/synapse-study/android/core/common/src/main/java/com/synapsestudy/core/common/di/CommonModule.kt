package com.synapsestudy.core.common.di

import com.synapsestudy.core.common.SystemTimeProvider
import com.synapsestudy.core.common.TimeProvider
import dagger.Binds
import dagger.Module
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
@Module
@InstallIn(SingletonComponent::class)
abstract class CommonModule {
    @Binds
    abstract fun bindTimeProvider(impl: SystemTimeProvider): TimeProvider
}
