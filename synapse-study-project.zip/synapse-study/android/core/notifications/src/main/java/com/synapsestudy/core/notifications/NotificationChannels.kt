package com.synapsestudy.core.notifications

import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.os.Build
import androidx.core.content.ContextCompat
import com.synapsestudy.core.model.NotificationChannelKey

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
object NotificationChannels {
    fun ensureChannelsCreated(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        val manager = ContextCompat.getSystemService(context, NotificationManager::class.java) ?: return

        val channels = listOf(
            channelFor(NotificationChannelKey.TASKS, "Tasks & deadlines", NotificationManager.IMPORTANCE_DEFAULT),
            channelFor(NotificationChannelKey.CALENDAR, "Calendar", NotificationManager.IMPORTANCE_DEFAULT),
            channelFor(NotificationChannelKey.FOCUS, "Focus timer", NotificationManager.IMPORTANCE_LOW),
            channelFor(NotificationChannelKey.STUDY_AI, "Study AI processing", NotificationManager.IMPORTANCE_LOW),
            channelFor(NotificationChannelKey.WELLNESS, "Wellness", NotificationManager.IMPORTANCE_DEFAULT),
            channelFor(NotificationChannelKey.SYSTEM, "System & storage", NotificationManager.IMPORTANCE_LOW)
        )
        channels.forEach { manager.createNotificationChannel(it) }
    }

    private fun channelFor(key: NotificationChannelKey, name: String, importance: Int): NotificationChannel =
        NotificationChannel(key.name, name, importance)
}
