package com.synapsestudy.core.notifications

import java.time.LocalTime

/**
 * STATUS: Generated, statically reviewed, not compiled.
 */
object QuietHours {
    fun isWithinQuietHours(nowTime: LocalTime, quietStart: LocalTime?, quietEnd: LocalTime?): Boolean {
        if (quietStart == null || quietEnd == null) return false
        return if (quietStart.isBefore(quietEnd)) {
            nowTime >= quietStart && nowTime < quietEnd
        } else {
            nowTime >= quietStart || nowTime < quietEnd
        }
    }
}
