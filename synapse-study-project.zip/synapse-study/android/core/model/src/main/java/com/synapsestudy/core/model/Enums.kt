package com.synapsestudy.core.model

/**
 * All shared enums used across domain entities.
 * STATUS: Generated, statically reviewed, not compiled.
 */
enum class TaskPriority { LOW, MEDIUM, HIGH, URGENT }
enum class TaskType { REVISION, PRACTICE, READING, ASSIGNMENT, EXAM_PREP, OTHER }
enum class SourceType { PDF, IMAGE, PASTED_TEXT, DOCX, OTHER }
enum class SourceProcessingState { PENDING, PROCESSING, READY, PARTIAL, FAILED }
enum class AiMode { SOURCE_ONLY, GENERAL_KNOWLEDGE }
enum class SupportStatus { GROUNDED, PARTIAL, UNSUPPORTED }
enum class GeneratedAssetType { SUMMARY, FLASHCARD_SET, QUIZ, REVISION_PDF, MIND_MAP, INFOGRAPHIC, SLIDESHOW, AUDIO_SUMMARY, VIDEO_SUMMARY }
enum class GenerationJobStatus { QUEUED, RUNNING, COMPLETED, FAILED, NOT_YET_SUPPORTED }
enum class MusicService { SPOTIFY, YOUTUBE_MUSIC, APPLE_MUSIC, OTHER }
enum class NotificationChannelKey { TASKS, CALENDAR, FOCUS, STUDY_AI, WELLNESS, SYSTEM }
enum class ThemeMode { LIGHT, DARK, SYSTEM, AMOLED }
enum class SyncMode { LOCAL_ONLY, GOOGLE_DRIVE }
