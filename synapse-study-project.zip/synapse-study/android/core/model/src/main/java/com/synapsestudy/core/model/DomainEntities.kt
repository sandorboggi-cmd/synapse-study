package com.synapsestudy.core.model

/**
 * Framework-agnostic domain models (no Room/Android annotations). Every
 * entity carries id/createdAt/updatedAt/schemaVersion/isArchived per the
 * project-wide convention so soft-delete and future migrations are
 * consistent everywhere.
 *
 * STATUS: Generated, statically reviewed, not compiled.
 */

interface SynapseEntity {
    val id: String
    val createdAt: Long
    val updatedAt: Long
    val schemaVersion: Int
    val isArchived: Boolean
}

data class UserSettings(
    override val id: String, val themeMode: String, val aiMode: String, val syncMode: String,
    val wellnessEnabled: Boolean, val dashboardCardOrderCsv: String,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class Subject(
    override val id: String, val name: String, val colorHex: String, val iconKey: String,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class Exam(
    override val id: String, val subjectId: String?, val name: String,
    val examDateEpochMillis: Long, val notes: String?,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class StudyHub(
    override val id: String, val title: String, val subjectId: String?, val examId: String?,
    val colorHex: String, val iconKey: String, val readinessPercent: Int,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class Task(
    override val id: String, val title: String, val notes: String?,
    val dueAtEpochMillis: Long?, val scheduledAtEpochMillis: Long?, val recurrenceRule: String?,
    val priority: TaskPriority, val taskType: TaskType, val tags: List<String>,
    val iconKey: String?, val colorHex: String?, val estimatedMinutes: Int?, val actualFocusMinutes: Int,
    val isCompleted: Boolean, val studyHubId: String?, val examId: String?, val subjectId: String?,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class Subtask(
    override val id: String, val taskId: String, val title: String, val isCompleted: Boolean,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class TaskLink(
    override val id: String, val taskId: String, val linkedEntityType: String, val linkedEntityId: String,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class CalendarEvent(
    override val id: String, val title: String, val startAtEpochMillis: Long, val endAtEpochMillis: Long,
    val relatedTaskId: String?, val relatedExamId: String?, val isUserPersonalEvent: Boolean,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class Source(
    override val id: String, val displayName: String, val sourceType: SourceType,
    val originalFileUri: String?, val processingState: SourceProcessingState,
    val currentVersionId: String?, val isAvailableOffline: Boolean,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class SourceVersion(
    override val id: String, val sourceId: String, val versionNumber: Int, val extractedText: String?,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class SourceAnchor(
    override val id: String, val sourceVersionId: String, val pageNumber: Int?, val charStart: Int?, val charEnd: Int?,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class SourceChunk(
    override val id: String, val sourceVersionId: String, val anchorId: String, val text: String, val chunkIndex: Int,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class Chat(
    override val id: String, val title: String, val aiMode: String, val selectedSourceIdsCsv: String,
    val studyHubId: String?, val taskId: String?,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class ChatMessage(
    override val id: String, val chatId: String, val role: String, val content: String, val supportStatus: String?,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class CitationAnchor(
    override val id: String, val chatMessageId: String, val sourceAnchorId: String,
    val evidenceChunkId: String, val quotedExcerpt: String,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class GeneratedAsset(
    override val id: String, val title: String, val assetType: String, val sourceJobId: String?, val filePath: String?,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class GenerationJob(
    override val id: String, val assetType: String, val status: String, val requestPayloadJson: String,
    val errorMessage: String?,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class FocusPreset(
    override val id: String, val name: String, val workMinutes: Int, val breakMinutes: Int, val cyclesBeforeLongBreak: Int,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class FocusSession(
    override val id: String, val presetId: String?, val taskId: String?, val subjectId: String?,
    val examId: String?, val studyHubId: String?, val startedAtEpochMillis: Long, val endedAtEpochMillis: Long?,
    val actualFocusMinutes: Int, val wasCompleted: Boolean,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class MusicTarget(
    override val id: String, val label: String, val service: String, val deepLinkUri: String,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class NotificationRule(
    override val id: String, val channelKey: String, val isEnabled: Boolean,
    val quietHoursStart: String?, val quietHoursEnd: String?,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class WellnessProfile(
    override val id: String, val isEnabled: Boolean, val companionType: String, val pronounPreference: String?,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class WellnessLog(
    override val id: String, val moodScore: Int, val reflectionTextEncrypted: String?,
    val hydrationLogged: Boolean, val breathingExerciseKey: String?,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity

data class LocalSyncOperation(
    override val id: String, val operationType: String, val entityType: String, val entityId: String, val payloadJson: String,
    override val createdAt: Long, override val updatedAt: Long,
    override val schemaVersion: Int = 1, override val isArchived: Boolean = false
) : SynapseEntity
