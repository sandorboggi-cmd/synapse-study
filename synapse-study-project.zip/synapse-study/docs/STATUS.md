# Synapse Study - Build Status

Last updated: 2026-08-03 (generation session 4, final assembly)

## IMPORTANT: Verification disclaimer

No file in this repository has been compiled, linted, or tested by the
assistant. The generation environment has no JDK, Android SDK, Gradle, or
emulator. Every source file is statically reviewed for syntax/API
consistency only. Status labels below reflect that honestly.

## All 25 modules are present

11 core modules (common, model, database, datastore, security, sync,
designsystem, navigation, notifications, testing, ui) and 14 feature
modules (onboarding, dashboard, tasks, calendar, studyhub, library,
sourceviewer, studyai, assets, focus, music, search, settings, wellness)
have generated source files, build.gradle.kts files, and are wired into
`settings.gradle.kts`. The `app` module ties them together with a single
Activity + Compose NavHost.

## Functional vs. stubbed (the honest breakdown)

| Area | Status |
|---|---|
| Room database (21 entities, FTS4, all DAOs) | Functional, statically reviewed |
| Task/Calendar/StudyHub/Library CRUD | Functional, statically reviewed |
| SOURCE_ONLY Study AI - local fake provider | Functional, deterministic, statically reviewed |
| SOURCE_ONLY Study AI - citation validation | Functional, 4 unit tests included |
| SOURCE_ONLY Study AI - Gemini network call | **Not implemented** - explicit `NotImplementedError`, endpoint documented inline |
| Semantic/embedding evidence retrieval | **Not implemented** - explicit `NotImplementedError`, lexical FTS retrieval works |
| PDF/OCR text extraction | **Not implemented** - `LocalSourceImportPipeline` honestly returns `PARTIAL` |
| Local backup (Local Only sync mode) | Functional, statically reviewed |
| Google Drive sync | **Not implemented** - requires your OAuth setup, returns honest "not configured" error |
| Video summary generation | **Not implemented** - returns `NOT_YET_SUPPORTED`, no fake output |
| Wellness module (isolated, opt-in) | Functional, statically reviewed, encrypted reflection storage |
| Notification channels + quiet hours | Functional, statically reviewed, not wired to WorkManager triggers yet |
| Focus timer engine | Functional, 3 unit tests included |

## Unit tests included (not run - no JVM/Gradle in this environment)

- `feature:studyai` - `ResponseValidatorTest.kt` (4 tests: grounded citation kept, invented citation dropped + downgraded to UNSUPPORTED, mixed valid/invented downgraded to PARTIAL, no-citation UNSUPPORTED preserved)
- `feature:focus` - `FocusTimerEngineTest.kt` (3 tests, from earlier session)
- `core:database` - `TaskDaoTest.kt` (2 instrumented tests, requires emulator/device)

## Known limitations / unverified assumptions

1. **Never compiled.** Gradle sync will likely surface at least minor errors (missing imports, Compose API signature mismatches for the exact pinned library versions) - I could not verify against a real toolchain.
2. Real PDF/OCR extraction, real Gemini network call, semantic retrieval, and Google Drive OAuth are intentionally stubbed with honest error states rather than faked, as documented above.
3. Task Detail tabs (Overview/Sources/Study AI Chats/Generated Outputs/Focus History/Activity), tablet two/three-pane layouts, drag-reposition calendar, flip-clock timer visuals, keyboard shortcuts, WorkManager/AlarmManager scheduling, and Media3 audio playback are NOT yet implemented.
4. `feature:studyai`'s chat screen currently opens a single hardcoded "default-chat" rather than a chat list/history UI.
5. No Compose UI tests or screenshot tests were generated.
6. Room schema `exportSchema = true` but no schema JSON has been generated (requires a real Gradle build).
7. Earlier feature modules (focus, music, search, settings, wellness, onboarding) were written before the final `core:database` DAO signatures were locked in this session - field/method name mismatches are possible and have not been cross-checked line by line.

## Commands you can run (not run by the assistant)

```
cd synapse-study/android
./gradlew build
./gradlew testDebugUnitTest
./gradlew connectedAndroidTest   # requires a device/emulator
./gradlew lintDebug
```

## Next planned implementation step

1. You run `./gradlew build` in Android Studio and report the first errors - this is genuinely the most valuable next input, since nothing here has touched a real compiler yet.
2. In parallel, next generation session should add: Task Detail tabs, two-pane tablet layouts, WorkManager notification workers, real PDF/OCR text extraction, a Study AI chat list/history screen, and Compose UI tests for Dashboard/Tasks/StudyAi.
