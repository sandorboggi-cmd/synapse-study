# Setup required from you

This project was generated in a sandbox with no JDK, Android SDK, or
emulator - so the following steps are genuinely yours to do, and are the
first things that will surface real errors for me to fix.

## 1. Required immediately

- Open `synapse-study/android/` in Android Studio (a recent stable version
  that supports AGP 8.6 / Kotlin 2.0).
- Let Gradle sync. **Copy me the exact error output** if it fails - version
  mismatches between AGP/Kotlin/Compose Compiler are the most likely first
  issue since I could not verify them against a real Gradle resolution.
- Run `./gradlew testDebugUnitTest` for the pure-JVM tests
  (`ResponseValidatorTest`, `FocusTimerEngineTest`) - these need no
  device/emulator.
- Run the app on a connected phone or tablet (Android 10+, API 26+).

## 2. Optional, for real Gemini calls

Currently `GeminiStudyAiProvider.callGeminiGenerateContent()` throws
`NotImplementedError` - it documents the exact REST call
(`POST https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=API_KEY`)
but I did not have network access to implement and test the real HTTP
client call in this session. Tell me to implement it and I will, using
your pasted Gemini API key (Settings screen already stores/retrieves it
via Android Keystore).

## 3. Optional, for Google Drive backup (Phase 4, not needed for normal use)

The app works fully in Local Only mode without this. If you later want
Google Drive app-data-folder backup:
1. Create a project in Google Cloud Console.
2. Enable the Drive API.
3. Create an OAuth 2.0 client ID (Android type), using your app's package
   name (`com.synapsestudy.app`) and SHA-1 signing fingerprint.
4. Add the `drive.appdata` scope only (not full Drive access).
5. Tell me the client ID and I will wire `GoogleDriveSyncProvider` to use it.

## 4. Not required

You do not need to write code, choose libraries, set up CI, configure
signing for release, or touch Play Console - none of that applies to a
personal single-device app.
